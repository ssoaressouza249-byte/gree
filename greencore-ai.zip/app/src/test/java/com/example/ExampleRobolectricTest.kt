package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.SessionManager
import com.example.engine.HardwareScanner
import com.example.engine.LocalBrainEngine
import com.example.engine.MathSolver
import com.example.engine.ProceduralArtEngine
import com.example.model.AuthProvider
import com.example.model.ResponseCategory
import com.example.model.UserSession
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `app name matches GreenCore AI`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("GreenCore AI", appName)
  }

  @Test
  fun `hardware scanner returns valid device profile`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val profile = HardwareScanner.scanDevice(context)
    assertTrue(profile.screenWidthPx > 0)
    assertTrue(profile.screenHeightPx > 0)
    assertTrue(profile.densityDpi > 0)
    assertTrue(profile.totalRamBytes > 0L)
  }

  @Test
  fun `local brain generates device calibrated sensitivity and brevent commands`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val profile = HardwareScanner.scanDevice(context)
    val brain = LocalBrainEngine()

    val reply = brain.processPrompt(context, "Gerar sensi, DPI e comando Brevent", profile)
    assertEquals(ResponseCategory.GAMER_SENSITIVITY, reply.category)
    assertTrue(reply.text.contains("Geral:"))
    assertTrue(reply.text.contains("Ponto Vermelho"))
    assertTrue(reply.text.contains("wm density"))
  }

  @Test
  fun `local brain generates procedural bitmap art`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val profile = HardwareScanner.scanDevice(context)
    val brain = LocalBrainEngine()

    val reply = brain.processPrompt(context, "Gerar wallpaper gamer cyberpunk", profile)
    assertEquals(ResponseCategory.PROCEDURAL_ART, reply.category)
    assertNotNull(reply.generatedArt)
    assertEquals(1080, reply.generatedArt?.bitmap?.width)
    assertEquals(1920, reply.generatedArt?.bitmap?.height)

    val logoArt = ProceduralArtEngine.generateArt("Criar logo neon GreenCore").getOrNull()
    assertNotNull(logoArt)
    assertEquals(1080, logoArt?.bitmap?.width)
    assertEquals(1080, logoArt?.bitmap?.height)
  }

  @Test
  fun `math solver solves quadratic and arithmetic`() {
    val arithmetic = MathSolver.trySolve("(15 + 5) * 3")
    assertNotNull(arithmetic)
    assertTrue(arithmetic!!.contains("60"))

    val quadratic = MathSolver.trySolve("x^2 - 5x + 6 = 0")
    assertNotNull(quadratic)
    assertTrue(quadratic!!.contains("3") && quadratic.contains("2"))
  }

  @Test
  fun `session manager persists and clears user session`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val manager = SessionManager(context)
    val session =
      UserSession(
        isAuthenticated = true,
        provider = AuthProvider.OFFLINE,
        displayName = "Sessão Local Offline",
        identifier = "local-device",
        loginTimestamp = 123456L,
      )
    manager.saveSession(session)
    val loaded = manager.loadSession()
    assertTrue(loaded.isAuthenticated)
    assertEquals(AuthProvider.OFFLINE, loaded.provider)

    manager.clearSession()
    assertTrue(!manager.loadSession().isAuthenticated)
  }
}
