package com.example.model

enum class AuthProvider(val label: String) {
  GOOGLE("Google (Gmail)"),
  GITHUB("GitHub"),
  OFFLINE("Modo Offline Local"),
}

data class UserSession(
  val isAuthenticated: Boolean = false,
  val provider: AuthProvider = AuthProvider.OFFLINE,
  val displayName: String = "",
  val identifier: String = "",
  val loginTimestamp: Long = 0L,
)
