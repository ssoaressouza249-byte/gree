package com.example.model

data class DeviceProfile(
  val manufacturer: String,
  val model: String,
  val deviceCode: String,
  val chipInfo: String,
  val androidVersion: String,
  val sdkInt: Int,
  val totalRamBytes: Long,
  val availableRamBytes: Long,
  val screenWidthPx: Int,
  val screenHeightPx: Int,
  val densityDpi: Int,
  val smallestWidthDp: Int,
  val currentRefreshRateHz: Float,
  val maxRefreshRateHz: Float,
) {
  val totalRamGb: Double
    get() = totalRamBytes / (1024.0 * 1024.0 * 1024.0)

  val availableRamGb: Double
    get() = availableRamBytes / (1024.0 * 1024.0 * 1024.0)

  val aspectRatioLabel: String
    get() {
      val longSide = maxOf(screenWidthPx, screenHeightPx).toFloat()
      val shortSide = minOf(screenWidthPx, screenHeightPx).coerceAtLeast(1).toFloat()
      val ratio = longSide / shortSide
      return String.format(java.util.Locale.US, "%.2f:1", ratio)
    }

  val performanceTier: String
    get() =
      when {
        totalRamGb >= 7.5 && maxRefreshRateHz >= 115f -> "Flagship / Competitive"
        totalRamGb >= 5.5 && maxRefreshRateHz >= 88f -> "Intermediário Avançado"
        totalRamGb >= 3.5 -> "Intermediário Padrão"
        else -> "Entrada / Otimização Máxima"
      }
}
