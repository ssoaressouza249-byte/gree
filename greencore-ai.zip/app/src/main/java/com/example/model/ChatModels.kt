package com.example.model

import android.graphics.Bitmap

enum class MessageSender {
  USER,
  AI,
}

enum class ResponseCategory(val badge: String) {
  SYSTEM("NÚCLEO"),
  GAMER_SENSITIVITY("CALIBRAGEM HARDWARE"),
  APP_MENTOR("MENTOR ARQUITETURA"),
  PROCEDURAL_ART("MOTOR GRÁFICO NATIVO"),
  FILE_INSPECTOR("INSPETOR DE ARQUIVOS"),
  KNOWLEDGE("BASE OFFLINE"),
}

data class GeneratedArtPayload(
  val bitmap: Bitmap,
  val title: String,
  val resolutionLabel: String,
  val styleLabel: String,
  val isSavedToGallery: Boolean = false,
  val savedUriString: String? = null,
)

data class AttachedFileMeta(
  val name: String,
  val extension: String,
  val sizeBytes: Long,
)

data class ChatMessage(
  val id: String,
  val sender: MessageSender,
  val text: String,
  val category: ResponseCategory = ResponseCategory.KNOWLEDGE,
  val timestampMs: Long = System.currentTimeMillis(),
  val attachedFile: AttachedFileMeta? = null,
  val generatedArt: GeneratedArtPayload? = null,
  val isReported: Boolean = false,
  val reportReason: String? = null,
)
