package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.model.AuthProvider
import com.example.model.UserSession

class SessionManager(context: Context) {

  private val prefs: SharedPreferences? =
    runCatching {
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
      }
      .getOrNull()

  fun loadSession(): UserSession {
    return runCatching {
        val p = prefs ?: return@runCatching UserSession()
        val isAuth = p.getBoolean(KEY_IS_AUTH, false)
        if (!isAuth) return@runCatching UserSession()

        val providerName = p.getString(KEY_PROVIDER, AuthProvider.OFFLINE.name)
        val provider =
          runCatching { AuthProvider.valueOf(providerName ?: AuthProvider.OFFLINE.name) }
            .getOrDefault(AuthProvider.OFFLINE)

        UserSession(
          isAuthenticated = true,
          provider = provider,
          displayName = p.getString(KEY_DISPLAY_NAME, "").orEmpty(),
          identifier = p.getString(KEY_IDENTIFIER, "").orEmpty(),
          loginTimestamp = p.getLong(KEY_TIMESTAMP, 0L),
        )
      }
      .getOrDefault(UserSession())
  }

  fun saveSession(session: UserSession) {
    runCatching {
      prefs
        ?.edit()
        ?.putBoolean(KEY_IS_AUTH, session.isAuthenticated)
        ?.putString(KEY_PROVIDER, session.provider.name)
        ?.putString(KEY_DISPLAY_NAME, session.displayName)
        ?.putString(KEY_IDENTIFIER, session.identifier)
        ?.putLong(KEY_TIMESTAMP, session.loginTimestamp)
        ?.apply()
    }
  }

  fun clearSession() {
    runCatching { prefs?.edit()?.clear()?.apply() }
  }

  private companion object {
    const val PREFS_NAME = "greencore_secure_session_prefs"
    const val KEY_IS_AUTH = "is_authenticated"
    const val KEY_PROVIDER = "auth_provider"
    const val KEY_DISPLAY_NAME = "display_name"
    const val KEY_IDENTIFIER = "identifier"
    const val KEY_TIMESTAMP = "login_timestamp"
  }
}
