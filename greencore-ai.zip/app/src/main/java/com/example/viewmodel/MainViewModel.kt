package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.SessionManager
import com.example.engine.FileInspectorEngine
import com.example.engine.HardwareScanner
import com.example.engine.LocalBrainEngine
import com.example.engine.ProceduralArtEngine
import com.example.model.AttachedFileMeta
import com.example.model.AuthProvider
import com.example.model.ChatMessage
import com.example.model.DeviceProfile
import com.example.model.MessageSender
import com.example.model.ResponseCategory
import com.example.model.UserSession
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class MainUiState(
  val session: UserSession = UserSession(),
  val deviceProfile: DeviceProfile? = null,
  val messages: List<ChatMessage> = emptyList(),
  val isProcessing: Boolean = false,
  val isAuthenticating: Boolean = false,
  val loginNotice: String? = null,
  val pendingAttachmentUri: Uri? = null,
  val pendingAttachmentMeta: AttachedFileMeta? = null,
  val snackbarMessage: String? = null,
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

  private val sessionManager = SessionManager(application)
  private val brainEngine = LocalBrainEngine()

  private val _uiState = MutableStateFlow(MainUiState())
  val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

  init {
    val savedSession = sessionManager.loadSession()
    val profile = HardwareScanner.scanDevice(application)
    _uiState.update {
      it.copy(
        session = savedSession,
        deviceProfile = profile,
        messages = if (savedSession.isAuthenticated) buildWelcomeMessages(profile) else emptyList(),
      )
    }
  }

  fun signInWithGoogle(activityContext: Context) {
    if (_uiState.value.isAuthenticating) return
    _uiState.update { it.copy(isAuthenticating = true, loginNotice = null) }

    viewModelScope.launch {
      val result =
        runCatching {
          val credentialManager = CredentialManager.create(activityContext)
          // Server Client ID placeholder for Google Cloud Console OAuth 2.0 Web Client
          val googleIdOption =
            GetGoogleIdOption.Builder()
              .setFilterByAuthorizedAccounts(false)
              .setServerClientId(GOOGLE_WEB_CLIENT_ID_PLACEHOLDER)
              .setAutoSelectEnabled(false)
              .build()

          val request = GetCredentialRequest.Builder().addCredentialOption(googleIdOption).build()
          val response = credentialManager.getCredential(activityContext, request)
          val credential = response.credential

          if (credential is CustomCredential &&
            credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
          ) {
            val googleCred = GoogleIdTokenCredential.createFrom(credential.data)
            UserSession(
              isAuthenticated = true,
              provider = AuthProvider.GOOGLE,
              displayName = googleCred.displayName ?: "Usuário Google",
              identifier = googleCred.id,
              loginTimestamp = System.currentTimeMillis(),
            )
          } else {
            error("Tipo de credencial inesperado.")
          }
        }

      result.fold(
        onSuccess = { session ->
          completeSignIn(session)
        },
        onFailure = { error ->
          val isCancelled = error is GetCredentialCancellationException
          val message =
            if (isCancelled) {
              "Login com Google cancelado pelo usuário."
            } else {
              "Credential Manager aguardando configuração de SHA-1 / Client ID no Console. Você pode usar o Modo Offline Local imediatamente ou prosseguir com sessão local."
            }
          _uiState.update {
            it.copy(
              isAuthenticating = false,
              loginNotice = message,
            )
          }
        },
      )
    }
  }

  fun signInWithGitHub(context: Context) {
    if (_uiState.value.isAuthenticating) return
    _uiState.update { it.copy(isAuthenticating = true, loginNotice = null) }

    val oauthLaunch =
      runCatching {
        val authUri =
          Uri.Builder()
            .scheme("https")
            .authority("github.com")
            .appendPath("login")
            .appendPath("oauth")
            .appendPath("authorize")
            .appendQueryParameter("client_id", GITHUB_CLIENT_ID_PLACEHOLDER)
            .appendQueryParameter("redirect_uri", GITHUB_REDIRECT_URI)
            .appendQueryParameter("scope", "read:user")
            .build()

        val intent =
          Intent(Intent.ACTION_VIEW, authUri).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
          }
        context.startActivity(intent)
      }

    oauthLaunch.fold(
      onSuccess = {
        _uiState.update {
          it.copy(
            isAuthenticating = false,
            loginNotice =
              "Fluxo OAuth GitHub aberto no navegador. Caso o OAuth App ainda não esteja vinculado, entre pelo Modo Offline Local abaixo.",
          )
        }
      },
      onFailure = {
        _uiState.update {
          it.copy(
            isAuthenticating = false,
            loginNotice =
              "Nenhum navegador disponível para o fluxo OAuth GitHub. Utilize o Modo Offline Local para acesso imediato.",
          )
        }
      },
    )
  }

  fun handleGitHubCallbackUri(uri: Uri?) {
    if (uri == null) return
    if (uri.scheme != "greencore" || uri.host != "oauth") return

    runCatching {
      val code = uri.getQueryParameter("code")
      val error = uri.getQueryParameter("error")
      if (!code.isNullOrBlank()) {
        val session =
          UserSession(
            isAuthenticated = true,
            provider = AuthProvider.GITHUB,
            displayName = "Conta GitHub Conectada",
            identifier = "oauth_code_${code.take(6)}",
            loginTimestamp = System.currentTimeMillis(),
          )
        completeSignIn(session)
      } else if (!error.isNullOrBlank()) {
        _uiState.update {
          it.copy(
            isAuthenticating = false,
            loginNotice = "Autorização GitHub recusada ($error). Você pode entrar via Modo Offline Local.",
          )
        }
      }
    }
  }

  fun signInOffline() {
    val session =
      UserSession(
        isAuthenticated = true,
        provider = AuthProvider.OFFLINE,
        displayName = "Sessão Local Offline",
        identifier = "local-device",
        loginTimestamp = System.currentTimeMillis(),
      )
    completeSignIn(session)
  }

  private fun completeSignIn(session: UserSession) {
    sessionManager.saveSession(session)
    val profile = _uiState.value.deviceProfile ?: HardwareScanner.scanDevice(getApplication())
    _uiState.update {
      it.copy(
        session = session,
        deviceProfile = profile,
        isAuthenticating = false,
        loginNotice = null,
        messages = if (it.messages.isEmpty()) buildWelcomeMessages(profile) else it.messages,
      )
    }
  }

  fun logout() {
    sessionManager.clearSession()
    _uiState.update {
      it.copy(
        session = UserSession(),
        messages = emptyList(),
        pendingAttachmentUri = null,
        pendingAttachmentMeta = null,
        loginNotice = null,
      )
    }
  }

  fun startNewChat() {
    val profile = _uiState.value.deviceProfile ?: HardwareScanner.scanDevice(getApplication())
    _uiState.update {
      it.copy(
        deviceProfile = profile,
        messages = buildWelcomeMessages(profile),
        pendingAttachmentUri = null,
        pendingAttachmentMeta = null,
      )
    }
  }

  fun refreshHardwareScan() {
    viewModelScope.launch {
      val profile =
        withContext(Dispatchers.Default) {
          HardwareScanner.scanDevice(getApplication())
        }
      _uiState.update { it.copy(deviceProfile = profile) }
    }
  }

  fun attachDocument(uri: Uri) {
    viewModelScope.launch {
      val report =
        withContext(Dispatchers.IO) {
          FileInspectorEngine.inspectUri(getApplication(), uri)
        }
      report.fold(
        onSuccess = { inspected ->
          val userBubble =
            ChatMessage(
              id = UUID.randomUUID().toString(),
              sender = MessageSender.USER,
              text = "Analisar arquivo anexado: ${inspected.meta.name}",
              attachedFile = inspected.meta,
            )
          val aiBubble =
            ChatMessage(
              id = UUID.randomUUID().toString(),
              sender = MessageSender.AI,
              text = inspected.summaryText,
              category = ResponseCategory.FILE_INSPECTOR,
              attachedFile = inspected.meta,
            )
          _uiState.update {
            it.copy(messages = it.messages + userBubble + aiBubble)
          }
        },
        onFailure = { err ->
          _uiState.update {
            it.copy(
              snackbarMessage =
                "Não foi possível ler o arquivo: ${err.localizedMessage ?: "erro de acesso"}",
            )
          }
        },
      )
    }
  }

  fun sendMessage(rawText: String) {
    val prompt = rawText.trim()
    val pendingUri = _uiState.value.pendingAttachmentUri
    if (prompt.isBlank() && pendingUri == null) return
    if (_uiState.value.isProcessing) return

    val userMessage =
      ChatMessage(
        id = UUID.randomUUID().toString(),
        sender = MessageSender.USER,
        text = prompt.ifBlank { "Analisar arquivo anexado" },
        attachedFile = _uiState.value.pendingAttachmentMeta,
      )

    _uiState.update {
      it.copy(
        messages = it.messages + userMessage,
        isProcessing = true,
        pendingAttachmentUri = null,
        pendingAttachmentMeta = null,
      )
    }

    viewModelScope.launch {
      val ctx = getApplication<Application>()
      val profile = _uiState.value.deviceProfile ?: HardwareScanner.scanDevice(ctx)

      val aiReply =
        withContext(Dispatchers.Default) {
          if (pendingUri != null) {
            brainEngine.inspectAttachedFile(ctx, pendingUri, prompt)
          } else {
            val reply = brainEngine.processPrompt(ctx, prompt, profile)
            ChatMessage(
              id = UUID.randomUUID().toString(),
              sender = MessageSender.AI,
              text = reply.text,
              category = reply.category,
              generatedArt = reply.generatedArt,
            )
          }
        }

      _uiState.update {
        it.copy(
          messages = it.messages + aiReply,
          isProcessing = false,
          deviceProfile = profile,
        )
      }
    }
  }

  fun saveGeneratedArt(messageId: String) {
    val target = _uiState.value.messages.find { it.id == messageId }?.generatedArt ?: return
    if (target.isSavedToGallery) {
      _uiState.update { it.copy(snackbarMessage = "Esta imagem já foi salva na galeria.") }
      return
    }

    viewModelScope.launch {
      val saveResult =
        withContext(Dispatchers.IO) {
          ProceduralArtEngine.saveBitmapToGallery(
            context = getApplication(),
            bitmap = target.bitmap,
            title = target.title,
          )
        }

      saveResult.fold(
        onSuccess = { location ->
          _uiState.update { state ->
            val updated =
              state.messages.map { msg ->
                if (msg.id == messageId && msg.generatedArt != null) {
                  msg.copy(
                    generatedArt =
                      msg.generatedArt.copy(
                        isSavedToGallery = true,
                        savedUriString = location,
                      ),
                  )
                } else {
                  msg
                }
              }
            state.copy(
              messages = updated,
              snackbarMessage = "Imagem salva em: $location",
            )
          }
        },
        onFailure = { err ->
          _uiState.update {
            it.copy(
              snackbarMessage =
                "Falha ao salvar na galeria: ${err.localizedMessage ?: "erro de gravação"}",
            )
          }
        },
      )
    }
  }

  fun reportAiResponse(messageId: String, reason: String) {
    _uiState.update { state ->
      val updated =
        state.messages.map { msg ->
          if (msg.id == messageId) {
            msg.copy(isReported = true, reportReason = reason)
          } else {
            msg
          }
        }
      state.copy(
        messages = updated,
        snackbarMessage = "Feedback registrado localmente ($reason). Obrigado por ajudar a melhorar a qualidade.",
      )
    }
  }

  fun clearSnackbar() {
    _uiState.update { it.copy(snackbarMessage = null) }
  }

  private fun buildWelcomeMessages(device: DeviceProfile): List<ChatMessage> {
    val welcome =
      buildString {
        appendLine("GREENCORE AI • MOTOR 100% OFFLINE PRONTO")
        appendLine("━━━━━━━━━━━━━━━━━━━━━━")
        appendLine("Hardware detectado automaticamente:")
        appendLine("• Aparelho: ${device.manufacturer} ${device.model}")
        appendLine("• Tela: ${device.screenWidthPx}×${device.screenHeightPx} px • ${device.densityDpi} DPI • ${device.maxRefreshRateHz.toInt()} Hz")
        appendLine("• Memória RAM: ${String.format(java.util.Locale.US, "%.1f", device.totalRamGb)} GB • Android ${device.androidVersion}")
        appendLine()
        append("Peça sua Sensi/DPI/Brevent, gere logos/wallpapers em 1080p, crie prompts de apps, resolva tarefas ou toque no clipe (📎) para inspecionar arquivos .apk, .zip, .sh e .kt.")
      }
    return listOf(
      ChatMessage(
        id = "welcome-core",
        sender = MessageSender.AI,
        text = welcome,
        category = ResponseCategory.SYSTEM,
      ),
    )
  }

  private companion object {
    // Configure com seu Web Client ID do Google Cloud Console para produção
    const val GOOGLE_WEB_CLIENT_ID_PLACEHOLDER = "000000000000-greencoreofflineplaceholder.apps.googleusercontent.com"
    const val GITHUB_CLIENT_ID_PLACEHOLDER = "greencore_ai_oauth_client"
    const val GITHUB_REDIRECT_URI = "greencore://oauth/github"
  }
}
