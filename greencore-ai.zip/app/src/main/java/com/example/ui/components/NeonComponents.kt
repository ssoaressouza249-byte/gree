package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.NeonBorderMuted
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonGreenSubtle
import com.example.ui.theme.PureBlack
import com.example.ui.theme.PureWhite
import com.example.ui.theme.UserBubbleDark
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun GreenCoreLogoMark(
  modifier: Modifier = Modifier,
  size: Dp = 64.dp,
) {
  Canvas(modifier = modifier.size(size)) {
    val cx = this.size.width / 2f
    val cy = this.size.height / 2f
    val radius = this.size.minDimension * 0.44f

    // Subtle radial glow
    drawCircle(
      brush =
        Brush.radialGradient(
          colors = listOf(NeonGreen.copy(alpha = 0.28f), Color.Transparent),
          center = Offset(cx, cy),
          radius = this.size.minDimension * 0.55f,
        ),
    )

    // Outer hexagon
    val hexPath = Path()
    for (i in 0 until 6) {
      val angle = (-PI / 2.0 + (2.0 * PI * i / 6.0)).toFloat()
      val x = cx + radius * cos(angle)
      val y = cy + radius * sin(angle)
      if (i == 0) hexPath.moveTo(x, y) else hexPath.lineTo(x, y)
    }
    hexPath.close()

    drawPath(
      path = hexPath,
      color = PureBlack,
    )
    drawPath(
      path = hexPath,
      color = NeonGreen,
      style = Stroke(width = radius * 0.11f, join = StrokeJoin.Round),
    )

    // Inner neural diamond/core traces
    val innerR = radius * 0.52f
    val corePath =
      Path().apply {
        moveTo(cx, cy - innerR)
        lineTo(cx + innerR * 0.85f, cy)
        lineTo(cx, cy + innerR)
        lineTo(cx - innerR * 0.85f, cy)
        close()
      }
    drawPath(
      path = corePath,
      color = NeonGreen,
      style = Stroke(width = radius * 0.08f, cap = StrokeCap.Round, join = StrokeJoin.Round),
    )
    drawLine(
      color = NeonGreen,
      start = Offset(cx, cy - innerR),
      end = Offset(cx, cy + innerR),
      strokeWidth = radius * 0.07f,
      cap = StrokeCap.Round,
    )
    drawCircle(
      color = NeonGreen,
      radius = radius * 0.14f,
      center = Offset(cx, cy),
    )
  }
}

@Composable
fun NeonStatusPill(
  text: String,
  modifier: Modifier = Modifier,
) {
  Row(
    modifier =
      modifier
        .clip(RoundedCornerShape(50))
        .background(NeonGreenSubtle)
        .border(1.dp, NeonGreen.copy(alpha = 0.55f), RoundedCornerShape(50))
        .padding(horizontal = 12.dp, vertical = 6.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    Box(
      modifier = Modifier.size(8.dp).clip(CircleShape).background(NeonGreen),
    )
    Text(
      text = text,
      color = NeonGreen,
      fontFamily = FontFamily.Monospace,
      fontWeight = FontWeight.Bold,
      fontSize = 11.sp,
      letterSpacing = 0.6.sp,
    )
  }
}

@Composable
fun NeonQuickChip(
  label: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Surface(
    modifier = modifier.minimumInteractiveComponentSize().clickable(onClick = onClick),
    shape = RoundedCornerShape(12.dp),
    color = UserBubbleDark,
    border = BorderStroke(1.dp, NeonBorderMuted),
  ) {
    Text(
      text = label,
      color = PureWhite,
      style = MaterialTheme.typography.labelMedium,
      modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
    )
  }
}
