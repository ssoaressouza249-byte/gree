package com.example.ui.screens

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.OfflineBolt
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.model.DeviceProfile
import com.example.ui.components.GreenCoreLogoMark
import com.example.ui.components.NeonStatusPill
import com.example.ui.theme.MutedText
import com.example.ui.theme.NeonBorderMuted
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.PureBlack
import com.example.ui.theme.PureWhite
import com.example.ui.theme.UserBubbleDark

@Composable
fun LoginScreen(
  deviceProfile: DeviceProfile?,
  isAuthenticating: Boolean,
  loginNotice: String?,
  onGoogleLogin: (Context) -> Unit,
  onGitHubLogin: (Context) -> Unit,
  onOfflineLogin: () -> Unit,
) {
  val context = LocalContext.current
  val activityContext = context.findActivity() ?: context

  Box(
    modifier =
      Modifier
        .fillMaxSize()
        .background(PureBlack),
  ) {
    // Subtle neon grid backdrop on pure black
    Canvas(modifier = Modifier.fillMaxSize()) {
      val step = 64.dp.toPx()
      var x = 0f
      while (x < size.width) {
        drawLine(
          color = NeonGreen.copy(alpha = 0.05f),
          start = Offset(x, 0f),
          end = Offset(x, size.height),
          strokeWidth = 1f,
        )
        x += step
      }
      var y = 0f
      while (y < size.height) {
        drawLine(
          color = NeonGreen.copy(alpha = 0.05f),
          start = Offset(0f, y),
          end = Offset(size.width, y),
          strokeWidth = 1f,
        )
        y += step
      }
      drawCircle(
        brush =
          Brush.radialGradient(
            colors = listOf(NeonGreen.copy(alpha = 0.14f), Color.Transparent),
            center = Offset(size.width / 2f, size.height * 0.25f),
            radius = size.minDimension * 0.65f,
          ),
      )
    }

    Column(
      modifier =
        Modifier
          .fillMaxSize()
          .windowInsetsPadding(WindowInsets.safeDrawing)
          .verticalScroll(rememberScrollState())
          .padding(horizontal = 24.dp, vertical = 24.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center,
    ) {
      Column(
        modifier = Modifier.widthIn(max = 480.dp).fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(18.dp),
      ) {
        GreenCoreLogoMark(size = 92.dp)

        NeonStatusPill(text = "KOTLIN CORE • 100% OFFLINE")

        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          Text(
            text = "GreenCore AI",
            style = MaterialTheme.typography.headlineLarge,
            color = PureWhite,
            textAlign = TextAlign.Center,
          )
          Text(
            text = "Análise de hardware, calibragem gamer, gerador procedural 1080p e inspetor técnico de arquivos.",
            style = MaterialTheme.typography.bodyMedium,
            color = MutedText,
            textAlign = TextAlign.Center,
          )
        }

        deviceProfile?.let { dev ->
          Surface(
            shape = RoundedCornerShape(14.dp),
            color = UserBubbleDark,
            border = BorderStroke(1.dp, NeonBorderMuted),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              Icon(
                imageVector = Icons.Filled.Shield,
                contentDescription = null,
                tint = NeonGreen,
                modifier = Modifier.size(18.dp),
              )
              Text(
                text = "Hardware detectado: ${dev.manufacturer} ${dev.model} (${dev.maxRefreshRateHz.toInt()}Hz)",
                style = MaterialTheme.typography.labelMedium,
                color = PureWhite,
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // 1. Google Credential Manager Login
        Button(
          onClick = { onGoogleLogin(activityContext) },
          enabled = !isAuthenticating,
          modifier =
            Modifier
              .fillMaxWidth()
              .height(54.dp)
              .testTag("google_login_button"),
          shape = RoundedCornerShape(16.dp),
          colors =
            ButtonDefaults.buttonColors(
              containerColor = NeonGreen,
              contentColor = PureBlack,
              disabledContainerColor = NeonGreen.copy(alpha = 0.5f),
            ),
        ) {
          if (isAuthenticating) {
            CircularProgressIndicator(
              color = PureBlack,
              strokeWidth = 2.5.dp,
              modifier = Modifier.size(20.dp),
            )
          } else {
            Icon(
              imageVector = Icons.Filled.AccountCircle,
              contentDescription = null,
              modifier = Modifier.size(22.dp),
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
              text = "Continuar com Google (Gmail)",
              fontWeight = FontWeight.ExtraBold,
              style = MaterialTheme.typography.titleMedium,
            )
          }
        }

        // 2. GitHub OAuth Web/Intent Login
        OutlinedButton(
          onClick = { onGitHubLogin(activityContext) },
          enabled = !isAuthenticating,
          modifier =
            Modifier
              .fillMaxWidth()
              .height(54.dp)
              .testTag("github_login_button"),
          shape = RoundedCornerShape(16.dp),
          border = BorderStroke(1.5.dp, NeonGreen),
          colors =
            ButtonDefaults.outlinedButtonColors(
              containerColor = UserBubbleDark,
              contentColor = PureWhite,
            ),
        ) {
          Icon(
            imageVector = Icons.Filled.Code,
            contentDescription = null,
            tint = NeonGreen,
            modifier = Modifier.size(20.dp),
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = "Continuar com GitHub",
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.titleMedium,
          )
        }

        AnimatedVisibility(visible = !loginNotice.isNullOrBlank()) {
          Surface(
            shape = RoundedCornerShape(14.dp),
            color = UserBubbleDark,
            border = BorderStroke(1.dp, NeonGreen.copy(alpha = 0.65f)),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Text(
              text = loginNotice.orEmpty(),
              style = MaterialTheme.typography.bodyMedium,
              color = PureWhite,
              modifier = Modifier.padding(14.dp),
            )
          }
        }

        // 3. Discreet Offline Mode Button
        TextButton(
          onClick = onOfflineLogin,
          modifier =
            Modifier
              .minimumInteractiveComponentSize()
              .testTag("offline_login_button"),
        ) {
          Icon(
            imageVector = Icons.Filled.OfflineBolt,
            contentDescription = null,
            tint = NeonGreen,
            modifier = Modifier.size(18.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "Entrar no Modo Offline Local",
            color = MutedText,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.SemiBold,
          )
        }
      }
    }
  }
}

private tailrec fun Context.findActivity(): Activity? =
  when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
  }
