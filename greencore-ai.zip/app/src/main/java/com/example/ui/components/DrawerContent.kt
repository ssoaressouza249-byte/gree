package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AddComment
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.DeviceProfile
import com.example.model.UserSession
import com.example.ui.theme.DangerRed
import com.example.ui.theme.DeepObsidian
import com.example.ui.theme.MutedText
import com.example.ui.theme.NeonBorderMuted
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonGreenSubtle
import com.example.ui.theme.PureBlack
import com.example.ui.theme.PureWhite
import com.example.ui.theme.UserBubbleDark

@Composable
fun GreenCoreDrawerContent(
  session: UserSession,
  deviceProfile: DeviceProfile?,
  onNewChat: () -> Unit,
  onOpenHardwareScanner: () -> Unit,
  onQuickPrompt: (String) -> Unit,
  onOpenFilePicker: () -> Unit,
  onLogout: () -> Unit,
) {
  ModalDrawerSheet(
    drawerContainerColor = DeepObsidian,
    drawerContentColor = PureWhite,
    modifier = Modifier.width(305.dp).fillMaxHeight(),
  ) {
    Column(
      modifier =
        Modifier
          .fillMaxHeight()
          .statusBarsPadding()
          .navigationBarsPadding()
          .padding(horizontal = 16.dp, vertical = 14.dp),
      verticalArrangement = Arrangement.SpaceBetween,
    ) {
      Column(
        modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        // Brand Header
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(12.dp),
          modifier = Modifier.padding(vertical = 6.dp),
        ) {
          GreenCoreLogoMark(size = 44.dp)
          Column {
            Text(
              text = "GreenCore AI",
              style = MaterialTheme.typography.titleLarge,
              color = PureWhite,
            )
            Text(
              text = "NÚCLEO OFFLINE NATIVO",
              style = MaterialTheme.typography.labelSmall,
              color = NeonGreen,
            )
          }
        }

        // Session Info Card
        Surface(
          shape = RoundedCornerShape(14.dp),
          color = UserBubbleDark,
          border = BorderStroke(1.dp, NeonBorderMuted),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
              Icon(
                imageVector = Icons.Filled.VerifiedUser,
                contentDescription = null,
                tint = NeonGreen,
                modifier = Modifier.size(16.dp),
              )
              Text(
                text = session.provider.label,
                style = MaterialTheme.typography.labelLarge,
                color = NeonGreen,
              )
            }
            Text(
              text = session.displayName.ifBlank { "Sessão Local" },
              style = MaterialTheme.typography.bodyMedium,
              color = PureWhite,
              fontWeight = FontWeight.SemiBold,
            )
            deviceProfile?.let { dev ->
              Text(
                text = "${dev.manufacturer} ${dev.model} • ${dev.maxRefreshRateHz.toInt()}Hz",
                style = MaterialTheme.typography.labelSmall,
                color = MutedText,
              )
            }
          }
        }

        Button(
          onClick = onNewChat,
          modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize().testTag("new_chat_button"),
          shape = RoundedCornerShape(14.dp),
          colors =
            ButtonDefaults.buttonColors(
              containerColor = NeonGreen,
              contentColor = PureBlack,
            ),
        ) {
          Icon(imageVector = Icons.Filled.AddComment, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text("Nova Conversa", fontWeight = FontWeight.Bold)
        }

        HorizontalDivider(color = NeonBorderMuted)

        Text(
          text = "FERRAMENTAS LOCAIS",
          style = MaterialTheme.typography.labelSmall,
          color = MutedText,
          modifier = Modifier.padding(start = 6.dp),
        )

        val itemColors =
          NavigationDrawerItemDefaults.colors(
            unselectedContainerColor = DeepObsidian,
            unselectedTextColor = PureWhite,
            unselectedIconColor = NeonGreen,
            selectedContainerColor = NeonGreenSubtle,
            selectedTextColor = NeonGreen,
            selectedIconColor = NeonGreen,
          )

        NavigationDrawerItem(
          label = { Text("Scanner de Hardware") },
          icon = { Icon(Icons.Filled.Memory, contentDescription = null) },
          selected = false,
          onClick = onOpenHardwareScanner,
          colors = itemColors,
        )

        NavigationDrawerItem(
          label = { Text("Calibrar Sensi, DPI & Brevent") },
          icon = { Icon(Icons.Filled.SportsEsports, contentDescription = null) },
          selected = false,
          onClick = { onQuickPrompt("Gerar sensi, HUD, DPI e comando Brevent para meu celular") },
          colors = itemColors,
        )

        NavigationDrawerItem(
          label = { Text("Gerar Arte / Wallpaper 1080p") },
          icon = { Icon(Icons.Filled.AutoAwesome, contentDescription = null) },
          selected = false,
          onClick = { onQuickPrompt("Gerar wallpaper gamer cyberpunk neon") },
          colors = itemColors,
        )

        NavigationDrawerItem(
          label = { Text("Mentor de Criação de Apps") },
          icon = { Icon(Icons.Filled.Code, contentDescription = null) },
          selected = false,
          onClick = { onQuickPrompt("Quero criar um app Android moderno") },
          colors = itemColors,
        )

        NavigationDrawerItem(
          label = { Text("Inspecionar Arquivo (.apk/.zip/.sh)") },
          icon = { Icon(Icons.Filled.FolderOpen, contentDescription = null) },
          selected = false,
          onClick = onOpenFilePicker,
          colors = itemColors,
        )
      }

      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        HorizontalDivider(color = NeonBorderMuted)
        Spacer(modifier = Modifier.height(2.dp))
        OutlinedButton(
          onClick = onLogout,
          modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize().testTag("logout_button"),
          shape = RoundedCornerShape(14.dp),
          border = BorderStroke(1.dp, DangerRed.copy(alpha = 0.7f)),
          colors = ButtonDefaults.outlinedButtonColors(contentColor = DangerRed),
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.Logout,
            contentDescription = null,
            modifier = Modifier.size(18.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "Sair da Sessão",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
          )
        }
      }
    }
  }
}
