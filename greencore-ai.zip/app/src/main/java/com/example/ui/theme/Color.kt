package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PureBlack = Color(0xFF000000)
val DeepObsidian = Color(0xFF070A08)
val UserBubbleDark = Color(0xFF141816)
val ElevatedDarkSurface = Color(0xFF0E1310)
val NeonGreen = Color(0xFF00FF66)
val NeonGreenDim = Color(0xFF00CC52)
val NeonGreenSubtle = Color(0xFF0D2A19)
val NeonBorderMuted = Color(0xFF1E3A28)
val PureWhite = Color(0xFFFFFFFF)
val MutedText = Color(0xFF9FB5A7)
val DangerRed = Color(0xFFFF4D4D)
val WarningAmber = Color(0xFFFFC107)
