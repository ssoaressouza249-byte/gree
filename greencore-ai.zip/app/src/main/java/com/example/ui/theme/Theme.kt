package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val GreenCoreColorScheme =
  darkColorScheme(
    primary = NeonGreen,
    onPrimary = PureBlack,
    primaryContainer = NeonGreenSubtle,
    onPrimaryContainer = NeonGreen,
    secondary = NeonGreenDim,
    onSecondary = PureBlack,
    secondaryContainer = UserBubbleDark,
    onSecondaryContainer = PureWhite,
    tertiary = NeonGreen,
    onTertiary = PureBlack,
    background = PureBlack,
    onBackground = PureWhite,
    surface = PureBlack,
    onSurface = PureWhite,
    surfaceVariant = UserBubbleDark,
    onSurfaceVariant = MutedText,
    surfaceContainerLowest = PureBlack,
    surfaceContainerLow = DeepObsidian,
    surfaceContainer = ElevatedDarkSurface,
    surfaceContainerHigh = UserBubbleDark,
    outline = NeonGreen,
    outlineVariant = NeonBorderMuted,
    error = DangerRed,
    onError = PureBlack,
  )

val GreenCoreShapes =
  Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(26.dp),
  )

@Composable
fun GreenCoreTheme(content: @Composable () -> Unit) {
  MaterialTheme(
    colorScheme = GreenCoreColorScheme,
    typography = Typography,
    shapes = GreenCoreShapes,
    content = content,
  )
}
