package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.InsertDriveFile
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.FileInspectorEngine
import com.example.model.ChatMessage
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonGreenDim
import com.example.ui.theme.PureBlack
import com.example.ui.theme.PureWhite
import com.example.ui.theme.UserBubbleDark

@Composable
fun UserMessageBubble(
  message: ChatMessage,
  modifier: Modifier = Modifier,
) {
  Row(
    modifier = modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.End,
  ) {
    Surface(
      modifier = Modifier.widthIn(max = 330.dp),
      shape = RoundedCornerShape(topStart = 20.dp, topEnd = 6.dp, bottomStart = 20.dp, bottomEnd = 20.dp),
      color = UserBubbleDark,
      border = BorderStroke(1.5.dp, NeonGreen),
    ) {
      Column(
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        message.attachedFile?.let { file ->
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = PureBlack,
            border = BorderStroke(1.dp, NeonGreen.copy(alpha = 0.55f)),
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Outlined.InsertDriveFile,
                contentDescription = "Arquivo anexado",
                tint = NeonGreen,
                modifier = Modifier.size(16.dp),
              )
              Text(
                text = "${file.name} (${FileInspectorEngine.formatBytes(file.sizeBytes)})",
                color = NeonGreen,
                style = MaterialTheme.typography.labelMedium,
              )
            }
          }
        }

        Text(
          text = message.text,
          color = PureWhite,
          style = MaterialTheme.typography.bodyLarge,
        )
      }
    }
  }
}

@Composable
fun AiResponseBubble(
  message: ChatMessage,
  onCopyText: (String) -> Unit,
  onSaveArt: (String) -> Unit,
  onReportClick: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  Surface(
    modifier = modifier.fillMaxWidth().testTag("ai_response_block"),
    shape = RoundedCornerShape(topStart = 8.dp, topEnd = 22.dp, bottomStart = 22.dp, bottomEnd = 22.dp),
    color = NeonGreen,
    tonalElevation = 0.dp,
  ) {
    Column(
      modifier = Modifier.padding(horizontal = 18.dp, vertical = 18.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      // Header pill
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Surface(
          shape = RoundedCornerShape(50),
          color = PureBlack,
        ) {
          Text(
            text = "GREENCORE // ${message.category.badge}",
            color = NeonGreen,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            letterSpacing = 0.6.sp,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
          )
        }
      }

      // Main high-contrast black text on vibrant #00FF66 green
      SelectionContainer {
        Text(
          text = message.text,
          color = PureBlack,
          fontFamily = FontFamily.Default,
          fontWeight = FontWeight.Medium,
          fontSize = 15.5.sp,
          lineHeight = 23.sp,
        )
      }

      // Procedural Canvas Bitmap Preview + Save to Gallery Button
      message.generatedArt?.let { art ->
        val imageBitmap = remember(art.bitmap) { art.bitmap.asImageBitmap() }
        val ratio = art.bitmap.width.toFloat() / art.bitmap.height.coerceAtLeast(1).toFloat()

        Surface(
          shape = RoundedCornerShape(16.dp),
          color = PureBlack,
          border = BorderStroke(2.dp, PureBlack),
        ) {
          Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            Box(
              modifier =
                Modifier
                  .fillMaxWidth()
                  .aspectRatio(ratio.coerceIn(0.55f, 1.8f))
                  .clip(RoundedCornerShape(12.dp))
                  .background(PureBlack),
            ) {
              Image(
                bitmap = imageBitmap,
                contentDescription = "Arte procedural gerada: ${art.title}",
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxWidth(),
              )
            }

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text(
                text = "${art.styleLabel} • ${art.resolutionLabel}",
                color = NeonGreen,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f).padding(end = 8.dp),
              )

              Button(
                onClick = { onSaveArt(message.id) },
                modifier = Modifier.minimumInteractiveComponentSize().testTag("save_gallery_button"),
                shape = RoundedCornerShape(12.dp),
                colors =
                  ButtonDefaults.buttonColors(
                    containerColor = NeonGreen,
                    contentColor = PureBlack,
                  ),
              ) {
                Icon(
                  imageVector = if (art.isSavedToGallery) Icons.Filled.CheckCircle else Icons.Filled.Download,
                  contentDescription = null,
                  modifier = Modifier.size(18.dp),
                )
                Spacer(modifier = Modifier.size(6.dp))
                Text(
                  text = if (art.isSavedToGallery) "Salvo" else "Salvar na Galeria",
                  fontWeight = FontWeight.ExtraBold,
                  fontSize = 12.5.sp,
                )
              }
            }
          }
        }
      }

      HorizontalDivider(color = PureBlack.copy(alpha = 0.22f), thickness = 1.dp)

      // Bottom action bar: Copy + Play Store compliant Report Response
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        TextButton(
          onClick = { onCopyText(message.text) },
          modifier = Modifier.minimumInteractiveComponentSize().testTag("copy_response_button"),
        ) {
          Icon(
            imageVector = Icons.Outlined.ContentCopy,
            contentDescription = "Copiar resposta",
            tint = PureBlack,
            modifier = Modifier.size(16.dp),
          )
          Spacer(modifier = Modifier.size(6.dp))
          Text(
            text = "Copiar",
            color = PureBlack,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
          )
        }

        TextButton(
          onClick = { if (!message.isReported) onReportClick(message.id) },
          enabled = !message.isReported,
          modifier = Modifier.minimumInteractiveComponentSize().testTag("report_response_button"),
        ) {
          Icon(
            imageVector = if (message.isReported) Icons.Filled.CheckCircle else Icons.Outlined.Flag,
            contentDescription = "Reportar Resposta",
            tint = PureBlack.copy(alpha = if (message.isReported) 0.55f else 0.85f),
            modifier = Modifier.size(15.dp),
          )
          Spacer(modifier = Modifier.size(5.dp))
          Text(
            text = if (message.isReported) "Reportada" else "Reportar Resposta",
            color = PureBlack.copy(alpha = if (message.isReported) 0.55f else 0.85f),
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.SemiBold,
            fontSize = 11.5.sp,
          )
        }
      }
    }
  }
}

@Composable
fun ProcessingIndicatorBubble(modifier: Modifier = Modifier) {
  Surface(
    modifier = modifier.fillMaxWidth(),
    shape = RoundedCornerShape(18.dp),
    color = NeonGreenDim,
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Text(
        text = "GREENCORE ENGINE // PROCESSANDO LOCALMENTE...",
        color = PureBlack,
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Bold,
        fontSize = 12.sp,
      )
    }
  }
}
