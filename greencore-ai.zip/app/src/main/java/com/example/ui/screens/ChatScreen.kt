package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.MessageSender
import com.example.ui.components.AiResponseBubble
import com.example.ui.components.GreenCoreDrawerContent
import com.example.ui.components.NeonQuickChip
import com.example.ui.components.ProcessingIndicatorBubble
import com.example.ui.components.ReportResponseDialog
import com.example.ui.components.UserMessageBubble
import com.example.ui.theme.MutedText
import com.example.ui.theme.NeonBorderMuted
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.PureBlack
import com.example.ui.theme.PureWhite
import com.example.ui.theme.UserBubbleDark
import com.example.viewmodel.MainUiState
import kotlin.math.roundToInt
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
  uiState: MainUiState,
  onSendMessage: (String) -> Unit,
  onAttachFileUri: (Uri) -> Unit,
  onSaveArt: (String) -> Unit,
  onReportResponse: (String, String) -> Unit,
  onNewChat: () -> Unit,
  onRefreshHardware: () -> Unit,
  onLogout: () -> Unit,
  onClearSnackbar: () -> Unit,
) {
  val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
  val scope = rememberCoroutineScope()
  val listState = rememberLazyListState()
  val snackbarHostState = remember { SnackbarHostState() }
  @Suppress("DEPRECATION")
  val clipboardManager = LocalClipboardManager.current

  var inputText by remember { mutableStateOf("") }
  var showHardwareSheet by remember { mutableStateOf(false) }
  var reportingMessageId by remember { mutableStateOf<String?>(null) }

  val documentPickerLauncher =
    rememberLauncherForActivityResult(contract = ActivityResultContracts.OpenDocument()) { uri ->
      uri?.let { onAttachFileUri(it) }
    }

  val openPicker: () -> Unit = {
    documentPickerLauncher.launch(arrayOf("*/*"))
  }

  // Handle back button when drawer or sheet is open
  BackHandler(enabled = drawerState.isOpen || showHardwareSheet || reportingMessageId != null) {
    when {
      reportingMessageId != null -> reportingMessageId = null
      showHardwareSheet -> showHardwareSheet = false
      drawerState.isOpen -> scope.launch { drawerState.close() }
    }
  }

  LaunchedEffect(uiState.messages.size) {
    if (uiState.messages.isNotEmpty()) {
      listState.animateScrollToItem(uiState.messages.lastIndex)
    }
  }

  LaunchedEffect(uiState.snackbarMessage) {
    val msg = uiState.snackbarMessage
    if (!msg.isNullOrBlank()) {
      snackbarHostState.showSnackbar(msg)
      onClearSnackbar()
    }
  }

  val quickPrompts =
    remember {
      listOf(
        "Sensi & Brevent" to "Gerar sensi, HUD, DPI e comando Brevent para meu celular",
        "Wallpaper Gamer" to "Gerar wallpaper gamer cyberpunk neon",
        "Criar Logo" to "Criar logo neon GreenCore",
        "Criar App" to "Quero criar um app Android de tarefas",
        "Bhaskara" to "x^2 - 5x + 6 = 0",
        "Roteiro Reels" to "Criar roteiro de vídeo gamer para Reels",
      )
    }

  ModalNavigationDrawer(
    drawerState = drawerState,
    drawerContent = {
      GreenCoreDrawerContent(
        session = uiState.session,
        deviceProfile = uiState.deviceProfile,
        onNewChat = {
          scope.launch { drawerState.close() }
          onNewChat()
        },
        onOpenHardwareScanner = {
          scope.launch { drawerState.close() }
          showHardwareSheet = true
        },
        onQuickPrompt = { prompt ->
          scope.launch { drawerState.close() }
          onSendMessage(prompt)
        },
        onOpenFilePicker = {
          scope.launch { drawerState.close() }
          openPicker()
        },
        onLogout = {
          scope.launch { drawerState.close() }
          onLogout()
        },
      )
    },
  ) {
    Scaffold(
      containerColor = PureBlack,
      contentWindowInsets = WindowInsets.safeDrawing,
      snackbarHost = {
        SnackbarHost(hostState = snackbarHostState) { data ->
          Snackbar(
            snackbarData = data,
            containerColor = UserBubbleDark,
            contentColor = NeonGreen,
            actionColor = NeonGreen,
            shape = RoundedCornerShape(14.dp),
          )
        }
      },
      topBar = {
        Column(modifier = Modifier.background(PureBlack)) {
          TopAppBar(
            colors =
              TopAppBarDefaults.topAppBarColors(
                containerColor = PureBlack,
                titleContentColor = PureWhite,
                navigationIconContentColor = NeonGreen,
                actionIconContentColor = NeonGreen,
              ),
            navigationIcon = {
              IconButton(
                onClick = { scope.launch { drawerState.open() } },
                modifier = Modifier.minimumInteractiveComponentSize().testTag("open_drawer_button"),
              ) {
                Icon(
                  imageVector = Icons.Filled.Menu,
                  contentDescription = "Abrir menu lateral",
                )
              }
            },
            title = {
              Column {
                Text(
                  text = "GreenCore AI",
                  style = MaterialTheme.typography.titleLarge,
                  color = PureWhite,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
                uiState.deviceProfile?.let { dev ->
                  Text(
                    text = "${dev.model} • ${dev.maxRefreshRateHz.roundToInt()}Hz • OFFLINE",
                    style = MaterialTheme.typography.labelSmall,
                    color = NeonGreen,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                  )
                }
              }
            },
            actions = {
              IconButton(
                onClick = { showHardwareSheet = true },
                modifier = Modifier.minimumInteractiveComponentSize().testTag("hardware_scanner_button"),
              ) {
                Icon(
                  imageVector = Icons.Filled.Memory,
                  contentDescription = "Scanner de hardware do aparelho",
                )
              }
            },
          )
          HorizontalDivider(color = NeonBorderMuted, thickness = 1.dp)
        }
      },
    ) { innerPadding ->
      Box(
        modifier =
          Modifier
            .fillMaxSize()
            .background(PureBlack)
            .padding(innerPadding)
            .imePadding(),
        contentAlignment = Alignment.TopCenter,
      ) {
        Column(
          modifier = Modifier.widthIn(max = 760.dp).fillMaxSize(),
        ) {
          // Quick Action Bar
          LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            items(quickPrompts) { (label, prompt) ->
              NeonQuickChip(
                label = label,
                onClick = { onSendMessage(prompt) },
              )
            }
          }

          // Messages List
          LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
          ) {
            items(uiState.messages, key = { it.id }) { msg ->
              when (msg.sender) {
                MessageSender.USER -> UserMessageBubble(message = msg)
                MessageSender.AI ->
                  AiResponseBubble(
                    message = msg,
                    onCopyText = { text ->
                      clipboardManager.setText(AnnotatedString(text))
                    },
                    onSaveArt = onSaveArt,
                    onReportClick = { msgId -> reportingMessageId = msgId },
                  )
              }
            }

            if (uiState.isProcessing) {
              item(key = "processing") {
                ProcessingIndicatorBubble()
              }
            }
          }

          // Bottom Input Composer
          Surface(
            color = PureBlack,
            border = BorderStroke(1.dp, NeonBorderMuted),
            modifier = Modifier.fillMaxWidth().navigationBarsPadding(),
          ) {
            Row(
              modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
              verticalAlignment = Alignment.Bottom,
              horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              // Attachment Clip Button (.apk, .zip, .txt, .sh, .kt, .xml, .json)
              IconButton(
                onClick = openPicker,
                modifier =
                  Modifier
                    .size(48.dp)
                    .testTag("attach_file_button"),
                colors =
                  IconButtonDefaults.iconButtonColors(
                    containerColor = UserBubbleDark,
                    contentColor = NeonGreen,
                  ),
              ) {
                Icon(
                  imageVector = Icons.Filled.AttachFile,
                  contentDescription = "Anexar arquivo (.apk, .zip, .txt, .sh, .kt, .xml)",
                )
              }

              OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                modifier = Modifier.weight(1f).testTag("chat_input_field"),
                placeholder = {
                  Text(
                    text = "Sensi, arte, app, conta ou anexo...",
                    color = MutedText,
                    style = MaterialTheme.typography.bodyMedium,
                  )
                },
                maxLines = 4,
                shape = RoundedCornerShape(18.dp),
                textStyle =
                  MaterialTheme.typography.bodyLarge.copy(
                    color = PureWhite,
                    fontFamily = FontFamily.Default,
                  ),
                colors =
                  OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = UserBubbleDark,
                    unfocusedContainerColor = UserBubbleDark,
                    focusedBorderColor = NeonGreen,
                    unfocusedBorderColor = NeonBorderMuted,
                    cursorColor = NeonGreen,
                    focusedTextColor = PureWhite,
                    unfocusedTextColor = PureWhite,
                  ),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions =
                  KeyboardActions(
                    onSend = {
                      if (inputText.isNotBlank()) {
                        onSendMessage(inputText)
                        inputText = ""
                      }
                    },
                  ),
              )

              Spacer(modifier = Modifier.size(2.dp))

              IconButton(
                onClick = {
                  if (inputText.isNotBlank()) {
                    onSendMessage(inputText)
                    inputText = ""
                  }
                },
                enabled = inputText.isNotBlank() && !uiState.isProcessing,
                modifier =
                  Modifier
                    .size(48.dp)
                    .background(
                      color = if (inputText.isNotBlank()) NeonGreen else UserBubbleDark,
                      shape = CircleShape,
                    )
                    .testTag("send_message_button"),
              ) {
                Icon(
                  imageVector = Icons.AutoMirrored.Filled.Send,
                  contentDescription = "Enviar mensagem",
                  tint = if (inputText.isNotBlank()) PureBlack else MutedText,
                )
              }
            }
          }
        }
      }
    }
  }

  if (showHardwareSheet) {
    HardwareScannerSheet(
      deviceProfile = uiState.deviceProfile,
      onDismiss = { showHardwareSheet = false },
      onRefreshScan = onRefreshHardware,
      onGenerateSensitivity = {
        onSendMessage("Gerar sensi, HUD, DPI e comando Brevent para meu celular")
      },
    )
  }

  reportingMessageId?.let { targetId ->
    ReportResponseDialog(
      onDismiss = { reportingMessageId = null },
      onConfirmReport = { reason ->
        onReportResponse(targetId, reason)
        reportingMessageId = null
      },
    )
  }
}
