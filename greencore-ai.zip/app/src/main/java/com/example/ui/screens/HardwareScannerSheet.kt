package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.DeviceProfile
import com.example.ui.theme.ElevatedDarkSurface
import com.example.ui.theme.MutedText
import com.example.ui.theme.NeonBorderMuted
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.PureBlack
import com.example.ui.theme.PureWhite
import com.example.ui.theme.UserBubbleDark
import java.util.Locale
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HardwareScannerSheet(
  deviceProfile: DeviceProfile?,
  onDismiss: () -> Unit,
  onRefreshScan: () -> Unit,
  onGenerateSensitivity: () -> Unit,
) {
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = ElevatedDarkSurface,
    contentColor = PureWhite,
  ) {
    Column(
      modifier =
        Modifier
          .fillMaxWidth()
          .navigationBarsPadding()
          .padding(horizontal = 20.dp)
          .padding(bottom = 24.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          Icon(
            imageVector = Icons.Filled.Memory,
            contentDescription = null,
            tint = NeonGreen,
            modifier = Modifier.size(26.dp),
          )
          Column {
            Text(
              text = "Scanner Automático de Hardware",
              style = MaterialTheme.typography.titleLarge,
              color = PureWhite,
            )
            Text(
              text = "TELEMETRIA NATIVA DO APARELHO",
              style = MaterialTheme.typography.labelSmall,
              color = NeonGreen,
            )
          }
        }

        IconButton(
          onClick = onRefreshScan,
          modifier = Modifier.minimumInteractiveComponentSize(),
        ) {
          Icon(
            imageVector = Icons.Filled.Refresh,
            contentDescription = "Atualizar leitura de hardware",
            tint = NeonGreen,
          )
        }
      }

      if (deviceProfile != null) {
        Surface(
          shape = RoundedCornerShape(16.dp),
          color = UserBubbleDark,
          border = BorderStroke(1.dp, NeonBorderMuted),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            MetricRow("Marca & Modelo", "${deviceProfile.manufacturer} ${deviceProfile.model}")
            MetricRow("Plataforma / SoC", "${deviceProfile.chipInfo} (${deviceProfile.deviceCode})")
            MetricRow("Android", "${deviceProfile.androidVersion} (API ${deviceProfile.sdkInt})")
            MetricRow(
              "Memória RAM Total",
              "${String.format(Locale.US, "%.2f", deviceProfile.totalRamGb)} GB (${String.format(Locale.US, "%.2f", deviceProfile.availableRamGb)} GB livre)",
            )
            MetricRow(
              "Resolução Real",
              "${deviceProfile.screenWidthPx} × ${deviceProfile.screenHeightPx} px (${deviceProfile.aspectRatioLabel})",
            )
            MetricRow(
              "Densidade / SW",
              "${deviceProfile.densityDpi} DPI • SW ${deviceProfile.smallestWidthDp} dp",
            )
            MetricRow(
              "Taxa de Atualização",
              "${deviceProfile.currentRefreshRateHz.roundToInt()} Hz (Máx: ${deviceProfile.maxRefreshRateHz.roundToInt()} Hz)",
            )
            MetricRow("Perfil de Desempenho", deviceProfile.performanceTier, highlight = true)
          }
        }

        Button(
          onClick = {
            onDismiss()
            onGenerateSensitivity()
          },
          modifier = Modifier.fillMaxWidth().height(52.dp).testTag("sheet_generate_sensi_button"),
          shape = RoundedCornerShape(14.dp),
          colors =
            ButtonDefaults.buttonColors(
              containerColor = NeonGreen,
              contentColor = PureBlack,
            ),
        ) {
          Icon(
            imageVector = Icons.Filled.SportsEsports,
            contentDescription = null,
            modifier = Modifier.size(20.dp),
          )
          Spacer(modifier = Modifier.size(8.dp))
          Text(
            text = "Calibrar Sensi, DPI & Brevent Agora",
            fontWeight = FontWeight.ExtraBold,
          )
        }
      }
    }
  }
}

@Composable
private fun MetricRow(
  label: String,
  value: String,
  highlight: Boolean = false,
) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.bodyMedium,
      color = MutedText,
      modifier = Modifier.weight(0.42f),
    )
    Text(
      text = value,
      fontFamily = FontFamily.Monospace,
      fontWeight = FontWeight.Bold,
      style = MaterialTheme.typography.bodyMedium,
      color = if (highlight) NeonGreen else PureWhite,
      modifier = Modifier.weight(0.58f),
    )
  }
}
