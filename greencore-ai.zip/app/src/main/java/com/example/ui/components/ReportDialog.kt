package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.theme.ElevatedDarkSurface
import com.example.ui.theme.MutedText
import com.example.ui.theme.NeonBorderMuted
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.PureBlack
import com.example.ui.theme.PureWhite
import com.example.ui.theme.UserBubbleDark

@Composable
fun ReportResponseDialog(
  onDismiss: () -> Unit,
  onConfirmReport: (String) -> Unit,
) {
  val reasons =
    remember {
      listOf(
        "Informação incorreta ou imprecisa",
        "Calibragem incompatível com o aparelho",
        "Conteúdo inadequado",
        "Erro na análise de arquivo ou código",
      )
    }
  var selectedReason by remember { mutableStateOf(reasons.first()) }

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = ElevatedDarkSurface,
    titleContentColor = PureWhite,
    textContentColor = MutedText,
    shape = RoundedCornerShape(20.dp),
    title = {
      Text(
        text = "Reportar Resposta da IA",
        style = MaterialTheme.typography.titleLarge,
        color = NeonGreen,
      )
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
          text = "Selecione o motivo para registrar esta ocorrência localmente (Política de Segurança de IA):",
          style = MaterialTheme.typography.bodyMedium,
          color = PureWhite,
        )
        reasons.forEach { reason ->
          val isSelected = selectedReason == reason
          Surface(
            modifier =
              Modifier.fillMaxWidth().clickable { selectedReason = reason },
            shape = RoundedCornerShape(12.dp),
            color = if (isSelected) UserBubbleDark else ElevatedDarkSurface,
            border = BorderStroke(1.dp, if (isSelected) NeonGreen else NeonBorderMuted),
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              RadioButton(
                selected = isSelected,
                onClick = { selectedReason = reason },
                colors =
                  RadioButtonDefaults.colors(
                    selectedColor = NeonGreen,
                    unselectedColor = MutedText,
                  ),
              )
              Text(
                text = reason,
                style = MaterialTheme.typography.bodyMedium,
                color = PureWhite,
                modifier = Modifier.padding(start = 6.dp),
              )
            }
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = { onConfirmReport(selectedReason) },
        modifier = Modifier.testTag("confirm_report_button"),
        colors =
          ButtonDefaults.buttonColors(
            containerColor = NeonGreen,
            contentColor = PureBlack,
          ),
      ) {
        Text("Enviar Reporte", fontWeight = FontWeight.Bold)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Cancelar", color = MutedText)
      }
    },
  )
}
