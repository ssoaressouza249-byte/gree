package com.example

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.theme.GreenCoreTheme
import com.example.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {

  private val viewModel: MainViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge(
      statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
      navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
    )

    viewModel.handleGitHubCallbackUri(intent?.data)

    setContent {
      GreenCoreTheme {
        val uiState by viewModel.uiState.collectAsStateWithLifecycle()

        AnimatedContent(
          targetState = uiState.session.isAuthenticated,
          label = "auth_transition",
        ) { isAuthenticated ->
          if (!isAuthenticated) {
            LoginScreen(
              deviceProfile = uiState.deviceProfile,
              isAuthenticating = uiState.isAuthenticating,
              loginNotice = uiState.loginNotice,
              onGoogleLogin = { ctx -> viewModel.signInWithGoogle(ctx) },
              onGitHubLogin = { ctx -> viewModel.signInWithGitHub(ctx) },
              onOfflineLogin = { viewModel.signInOffline() },
            )
          } else {
            ChatScreen(
              uiState = uiState,
              onSendMessage = { text -> viewModel.sendMessage(text) },
              onAttachFileUri = { uri -> viewModel.attachDocument(uri) },
              onSaveArt = { id -> viewModel.saveGeneratedArt(id) },
              onReportResponse = { id, reason -> viewModel.reportAiResponse(id, reason) },
              onNewChat = { viewModel.startNewChat() },
              onRefreshHardware = { viewModel.refreshHardwareScan() },
              onLogout = { viewModel.logout() },
              onClearSnackbar = { viewModel.clearSnackbar() },
            )
          }
        }
      }
    }
  }

  override fun onNewIntent(intent: Intent) {
    super.onNewIntent(intent)
    setIntent(intent)
    viewModel.handleGitHubCallbackUri(intent.data)
  }
}
