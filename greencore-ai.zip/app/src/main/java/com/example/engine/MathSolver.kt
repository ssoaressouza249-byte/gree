package com.example.engine

import java.util.Locale
import kotlin.math.pow
import kotlin.math.sqrt

object MathSolver {

  fun trySolve(rawInput: String): String? {
    val cleaned = rawInput.trim()
    if (cleaned.isBlank()) return null

    // 1. Check percentage pattern like "15% de 240" or "20% of 150"
    val percentRegex = Regex("""(\d+(?:[.,]\d+)?)\s*%\s*(?:de|of)\s*(\d+(?:[.,]\d+)?)""", RegexOption.IGNORE_CASE)
    percentRegex.find(cleaned)?.let { match ->
      val pct = match.groupValues[1].replace(",", ".").toDoubleOrNull()
      val base = match.groupValues[2].replace(",", ".").toDoubleOrNull()
      if (pct != null && base != null) {
        val result = (pct / 100.0) * base
        return buildString {
          appendLine("Cálculo de Porcentagem:")
          appendLine("• Expressão: ${formatNum(pct)}% de ${formatNum(base)}")
          appendLine("• Fórmula: (${formatNum(pct)} ÷ 100) × ${formatNum(base)}")
          append("• Resultado: ${formatNum(result)}")
        }
      }
    }

    // 2. Check quadratic equation like "x^2 - 5x + 6 = 0" or "2x² + 4x - 6 = 0"
    val quadSolution = trySolveQuadratic(cleaned)
    if (quadSolution != null) return quadSolution

    // 3. Extract pure arithmetic expression if present
    val expr = extractArithmeticExpression(cleaned) ?: return null
    val evaluated = runCatching { evaluateExpression(expr) }.getOrNull() ?: return null
    if (evaluated.isNaN() || evaluated.isInfinite()) return null

    return buildString {
      appendLine("Resolução Matemática:")
      appendLine("• Expressão detectada: $expr")
      append("• Resultado exato: ${formatNum(evaluated)}")
    }
  }

  private fun trySolveQuadratic(input: String): String? {
    val normalized =
      input
        .lowercase(Locale.getDefault())
        .replace("²", "^2")
        .replace(",", ".")
        .replace(" ", "")
    if (!normalized.contains("x^2") || !normalized.contains("=0")) return null

    val leftSide = normalized.substringBefore("=0")
    val aMatch = Regex("""([+-]?\d*(?:\.\d+)?)x\^2""").find(leftSide) ?: return null
    val aStr = aMatch.groupValues[1]
    val a =
      when (aStr) {
        "", "+" -> 1.0
        "-" -> -1.0
        else -> aStr.toDoubleOrNull() ?: return null
      }
    if (a == 0.0) return null

    val withoutA = leftSide.replaceFirst(aMatch.value, "")
    val bMatch = Regex("""([+-]?\d*(?:\.\d+)?)x(?!\^)""").find(withoutA)
    val b =
      if (bMatch != null) {
        when (val bStr = bMatch.groupValues[1]) {
          "", "+" -> 1.0
          "-" -> -1.0
          else -> bStr.toDoubleOrNull() ?: 0.0
        }
      } else {
        0.0
      }

    val withoutB = if (bMatch != null) withoutA.replaceFirst(bMatch.value, "") else withoutA
    val c = if (withoutB.isBlank()) 0.0 else withoutB.toDoubleOrNull() ?: return null

    val delta = b * b - 4.0 * a * c
    return buildString {
      appendLine("Equação do 2º Grau (Fórmula de Bhaskara):")
      appendLine("• Coeficientes: a = ${formatNum(a)}, b = ${formatNum(b)}, c = ${formatNum(c)}")
      appendLine("• Δ = b² - 4ac = (${formatNum(b)})² - 4(${formatNum(a)})(${formatNum(c)}) = ${formatNum(delta)}")
      when {
        delta > 0.0 -> {
          val x1 = (-b + sqrt(delta)) / (2.0 * a)
          val x2 = (-b - sqrt(delta)) / (2.0 * a)
          appendLine("• x₁ = ${formatNum(x1)}")
          append("• x₂ = ${formatNum(x2)}")
        }
        delta == 0.0 -> {
          val x = -b / (2.0 * a)
          append("• Raiz única real: x = ${formatNum(x)}")
        }
        else -> {
          append("• Δ < 0: Não existem raízes reais no conjunto ℝ.")
        }
      }
    }
  }

  private fun extractArithmeticExpression(input: String): String? {
    val normalized =
      input
        .replace("×", "*")
        .replace("x", "*")
        .replace("÷", "/")
        .replace(",", ".")
    val candidate = Regex("""[0-9().+\-*/^\s]{3,}""").findAll(normalized)
      .map { it.value.trim() }
      .maxByOrNull { it.length } ?: return null

    val hasOperator = candidate.any { it == '+' || it == '-' || it == '*' || it == '/' || it == '^' }
    val hasDigit = candidate.any { it.isDigit() }
    return if (hasOperator && hasDigit) candidate else null
  }

  private fun evaluateExpression(expr: String): Double {
    return ExpressionParser(expr.replace(" ", "")).parse()
  }

  private class ExpressionParser(private val sanitized: String) {
    private var pos = -1
    private var ch = 0

    fun parse(): Double {
      nextChar()
      val result = parseExpression()
      if (pos < sanitized.length) throw IllegalArgumentException("Unexpected trailing char")
      return result
    }

    private fun nextChar() {
      pos++
      ch = if (pos < sanitized.length) sanitized[pos].code else -1
    }

    private fun eat(charToEat: Int): Boolean {
      while (ch == ' '.code) nextChar()
      if (ch == charToEat) {
        nextChar()
        return true
      }
      return false
    }

    private fun parseExpression(): Double {
      var x = parseTerm()
      while (true) {
        x =
          when {
            eat('+'.code) -> x + parseTerm()
            eat('-'.code) -> x - parseTerm()
            else -> return x
          }
      }
    }

    private fun parseTerm(): Double {
      var x = parseFactor()
      while (true) {
        x =
          when {
            eat('*'.code) -> x * parseFactor()
            eat('/'.code) -> x / parseFactor()
            else -> return x
          }
      }
    }

    private fun parseFactor(): Double {
      if (eat('+'.code)) return parseFactor()
      if (eat('-'.code)) return -parseFactor()

      var x: Double
      val startPos = pos
      if (eat('('.code)) {
        x = parseExpression()
        if (!eat(')'.code)) throw IllegalArgumentException("Missing )")
      } else if ((ch in '0'.code..'9'.code) || ch == '.'.code) {
        while ((ch in '0'.code..'9'.code) || ch == '.'.code) nextChar()
        x = sanitized.substring(startPos, pos).toDouble()
      } else {
        throw IllegalArgumentException("Unexpected char: ${ch.toChar()}")
      }

      if (eat('^'.code)) x = x.pow(parseFactor())
      return x
    }
  }

  private fun formatNum(value: Double): String {
    return if (value % 1.0 == 0.0 && value in -1e12..1e12) {
      value.toLong().toString()
    } else {
      String.format(Locale.US, "%.4f", value).trimEnd('0').trimEnd('.')
    }
  }
}
