package com.example.engine

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import com.example.model.AttachedFileMeta
import java.io.BufferedInputStream
import java.io.BufferedReader
import java.io.File
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.util.Locale
import java.util.zip.ZipInputStream

data class FileInspectionReport(
  val meta: AttachedFileMeta,
  val summaryText: String,
)

object FileInspectorEngine {

  fun inspectUri(context: Context, uri: Uri, userNote: String = ""): Result<FileInspectionReport> {
    return runCatching {
      val meta = queryFileMeta(context, uri)
      val ext = meta.extension.lowercase(Locale.US)

      val analysis =
        when (ext) {
          "apk" -> inspectApk(context, uri, meta)
          "zip" -> inspectZip(context, uri, meta)
          "txt", "sh", "kt", "xml", "json", "kts", "gradle", "md", "properties" ->
            inspectTextCode(context, uri, meta, ext)
          else -> inspectFallbackTextOrBinary(context, uri, meta)
        }

      val finalText =
        buildString {
          appendLine("RELATÓRIO DE INSPEÇÃO DE ARQUIVO")
          appendLine("━━━━━━━━━━━━━━━━━━━━━━")
          appendLine("Arquivo: ${meta.name}")
          appendLine("Formato: .${meta.extension.uppercase(Locale.US)} | Tamanho: ${formatBytes(meta.sizeBytes)}")
          if (userNote.isNotBlank()) {
            appendLine("Solicitação do usuário: \"$userNote\"")
          }
          appendLine()
          append(analysis)
        }

      FileInspectionReport(meta = meta, summaryText = finalText)
    }
  }

  private fun queryFileMeta(context: Context, uri: Uri): AttachedFileMeta {
    var displayName = "arquivo_anexado"
    var sizeBytes = 0L

    runCatching {
      context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
        val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
        if (cursor.moveToFirst()) {
          if (nameIdx >= 0) {
            cursor.getString(nameIdx)?.takeIf { it.isNotBlank() }?.let { displayName = it }
          }
          if (sizeIdx >= 0 && !cursor.isNull(sizeIdx)) {
            sizeBytes = cursor.getLong(sizeIdx).coerceAtLeast(0L)
          }
        }
      }
    }

    if (displayName == "arquivo_anexado") {
      uri.lastPathSegment?.substringAfterLast('/')?.takeIf { it.isNotBlank() }?.let {
        displayName = it
      }
    }

    val ext = displayName.substringAfterLast('.', "").lowercase(Locale.US).ifBlank { "bin" }
    return AttachedFileMeta(name = displayName, extension = ext, sizeBytes = sizeBytes)
  }

  private fun inspectApk(context: Context, uri: Uri, meta: AttachedFileMeta): String {
    var tempFile: File? = null
    return try {
      tempFile = File(context.cacheDir, "inspect_${System.currentTimeMillis()}.apk")
      var copiedBytes = 0L
      context.contentResolver.openInputStream(uri)?.use { input ->
        FileOutputStream(tempFile).use { output ->
          val buffer = ByteArray(8192)
          var read: Int
          while (input.read(buffer).also { read = it } != -1) {
            output.write(buffer, 0, read)
            copiedBytes += read
          }
        }
      } ?: return "Erro: não foi possível abrir o fluxo de leitura do arquivo APK."

      val pm = context.packageManager
      val pkgInfo: PackageInfo? =
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
              pm.getPackageArchiveInfo(
                tempFile.absolutePath,
                PackageManager.PackageInfoFlags.of(PackageManager.GET_PERMISSIONS.toLong()),
              )
            } else {
              @Suppress("DEPRECATION")
              pm.getPackageArchiveInfo(tempFile.absolutePath, PackageManager.GET_PERMISSIONS)
            }
          }
          .getOrNull()

      if (pkgInfo == null) {
        return "Não foi possível decodificar o manifesto interno do APK (${formatBytes(copiedBytes)}). O pacote pode estar corrompido ou incompleto."
      }

      val appInfo = pkgInfo.applicationInfo
      val appLabel =
        runCatching {
            if (appInfo != null) {
              appInfo.sourceDir = tempFile.absolutePath
              appInfo.publicSourceDir = tempFile.absolutePath
              appInfo.loadLabel(pm).toString()
            } else {
              meta.name
            }
          }
          .getOrDefault(meta.name)

      val versionCode =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
          pkgInfo.longVersionCode
        } else {
          @Suppress("DEPRECATION")
          pkgInfo.versionCode.toLong()
        }

      val minSdk = appInfo?.minSdkVersion ?: -1
      val targetSdk = appInfo?.targetSdkVersion ?: -1
      val permissions = pkgInfo.requestedPermissions?.toList().orEmpty()

      buildString {
        appendLine("ANÁLISE DO PACOTE ANDROID (.APK)")
        appendLine("• Nome do App: $appLabel")
        appendLine("• Package Name: ${pkgInfo.packageName}")
        appendLine("• Versão: ${pkgInfo.versionName ?: "N/D"} (Code: $versionCode)")
        appendLine("• SDK Mínimo: ${if (minSdk > 0) minSdk else "N/D"} | Target SDK: ${if (targetSdk > 0) targetSdk else "N/D"}")
        appendLine("• Tamanho Real: ${formatBytes(copiedBytes)}")
        appendLine()
        appendLine("PERMISSÕES DECLARADAS (${permissions.size}):")
        if (permissions.isEmpty()) {
          appendLine("• Nenhuma permissão declarada (App Zero-Permission).")
        } else {
          permissions.take(18).forEach { perm ->
            val shortPerm = perm.substringAfterLast('.')
            val tag =
              when {
                shortPerm.contains("STORAGE") || shortPerm.contains("MEDIA") -> " [Atenção Play Store]"
                shortPerm.contains("INSTALL_PACKAGES") -> " [Alto Risco]"
                shortPerm == "INTERNET" -> " [Rede]"
                else -> ""
              }
            appendLine("• $shortPerm$tag")
          }
          if (permissions.size > 18) {
            appendLine("• ... e mais ${permissions.size - 18} permissões.")
          }
        }
      }
    } finally {
      runCatching { tempFile?.delete() }
    }
  }

  private fun inspectZip(context: Context, uri: Uri, meta: AttachedFileMeta): String {
    val entries = mutableListOf<String>()
    var fileCount = 0
    var dirCount = 0
    var totalUncompressed = 0L
    var kotlinFiles = 0
    var javaFiles = 0
    var xmlFiles = 0

    var hasGradle = false
    var hasSettingsGradle = false
    var hasManifest = false
    var hasVersionCatalog = false
    var hasMainSrc = false

    context.contentResolver.openInputStream(uri)?.use { raw ->
      ZipInputStream(BufferedInputStream(raw)).use { zis ->
        var entry = zis.nextEntry
        while (entry != null) {
          val name = entry.name
          if (entry.isDirectory) {
            dirCount++
          } else {
            fileCount++
            if (entry.size > 0) totalUncompressed += entry.size
            if (entries.size < 25) entries.add(name)

            val lower = name.lowercase(Locale.US)
            if (lower.endsWith("build.gradle") || lower.endsWith("build.gradle.kts")) hasGradle = true
            if (lower.endsWith("settings.gradle") || lower.endsWith("settings.gradle.kts")) hasSettingsGradle = true
            if (lower.endsWith("androidmanifest.xml")) hasManifest = true
            if (lower.endsWith("libs.versions.toml")) hasVersionCatalog = true
            if (lower.contains("src/main/")) hasMainSrc = true
            if (lower.endsWith(".kt")) kotlinFiles++
            if (lower.endsWith(".java")) javaFiles++
            if (lower.endsWith(".xml")) xmlFiles++
          }
          zis.closeEntry()
          entry = zis.nextEntry
        }
      }
    } ?: return "Erro: não foi possível abrir o arquivo ZIP."

    val isAndroidProject = (hasGradle && hasManifest) || (hasGradle && hasMainSrc)

    return buildString {
      appendLine("INSPEÇÃO DE ARQUIVO COMPACTADO (.ZIP)")
      appendLine("• Total de arquivos: $fileCount | Pastas: $dirCount")
      if (totalUncompressed > 0L) {
        appendLine("• Tamanho descompactado estimado: ${formatBytes(totalUncompressed)}")
      }
      appendLine(
        "• Projeto Android / Gradle detectado: ${
          if (isAndroidProject) "SIM (Estrutura Gradle + AndroidManifest confirmada)" else "NÃO / Arquivo genérico"
        }",
      )
      if (isAndroidProject) {
        appendLine("• Marcadores encontrados:")
        if (hasGradle) appendLine("  - build.gradle / build.gradle.kts")
        if (hasSettingsGradle) appendLine("  - settings.gradle")
        if (hasVersionCatalog) appendLine("  - gradle/libs.versions.toml")
        if (hasManifest) appendLine("  - AndroidManifest.xml")
        appendLine("• Contagem de código: $kotlinFiles .kt | $javaFiles .java | $xmlFiles .xml")
      }
      appendLine()
      appendLine("ESTRUTURA INTERNA (primeiros ${entries.size} arquivos):")
      entries.forEach { appendLine("• $it") }
      if (fileCount > entries.size) {
        appendLine("• ... e mais ${fileCount - entries.size} arquivos.")
      }
    }
  }

  private fun inspectTextCode(
    context: Context,
    uri: Uri,
    meta: AttachedFileMeta,
    ext: String,
  ): String {
    val lines = mutableListOf<String>()
    var totalLines = 0
    var truncated = false

    context.contentResolver.openInputStream(uri)?.use { input ->
      BufferedReader(InputStreamReader(input, Charsets.UTF_8)).use { reader ->
        var line = reader.readLine()
        while (line != null) {
          totalLines++
          if (lines.size < 300) {
            lines.add(line)
          } else {
            truncated = true
          }
          line = reader.readLine()
        }
      }
    } ?: return "Erro: não foi possível ler o conteúdo textual do arquivo."

    val content = lines.joinToString("\n")
    val diagnostics = mutableListOf<String>()
    val highlights = mutableListOf<String>()

    when (ext) {
      "sh" -> {
        if (!content.trimStart().startsWith("#!")) {
          diagnostics.add("Aviso: script sem cabeçalho shebang (ex: #!/system/bin/sh ou #!/bin/bash).")
        } else {
          highlights.add("Shebang identificado: ${lines.firstOrNull().orEmpty()}")
        }
        val adbCmds = lines.filter {
          val l = it.trim()
          l.startsWith("wm ") || l.startsWith("settings ") || l.startsWith("cmd ") || l.startsWith("am ") || l.startsWith("setprop ")
        }
        if (adbCmds.isNotEmpty()) {
          highlights.add("Comandos de sistema/Brevent detectados (${adbCmds.size}): ${adbCmds.take(4).joinToString(" | ")}")
        }
        if (content.contains("rm -rf") || content.contains("su -c") || content.contains("dd if=")) {
          diagnostics.add("Alerta de Segurança: comando destrutivo ou privilegiado encontrado (rm -rf / su / dd). Revise antes de executar.")
        }
      }
      "kt", "kts" -> {
        val classes = Regex("""\b(class|object|interface|fun)\s+([A-Za-z0-9_]+)""").findAll(content).map { "${it.groupValues[1]} ${it.groupValues[2]}" }.toList()
        if (classes.isNotEmpty()) {
          highlights.add("Declarações Kotlin encontradas: ${classes.take(8).joinToString(", ")}")
        }
        val composables = Regex("""@Composable\s+fun\s+([A-Za-z0-9_]+)""").findAll(content).map { it.groupValues[1] }.toList()
        if (composables.isNotEmpty()) {
          highlights.add("Composables Jetpack Compose: ${composables.take(6).joinToString(", ")}")
        }
        val openBraces = content.count { it == '{' }
        val closeBraces = content.count { it == '}' }
        if (openBraces != closeBraces) {
          diagnostics.add("Possível erro de sintaxe: chaves desbalanceadas ('{' = $openBraces vs '}' = $closeBraces).")
        }
      }
      "xml" -> {
        val permissions = Regex("""android:name="android\.permission\.([A-Z0-9_]+)"""").findAll(content).map { it.groupValues[1] }.toList()
        if (permissions.isNotEmpty()) {
          highlights.add("Permissões XML encontradas: ${permissions.joinToString(", ")}")
        }
        val openTags = Regex("""<([A-Za-z0-9_:-]+)(?=[\s>])""").findAll(content).count()
        if (openTags == 0) {
          diagnostics.add("Aviso: nenhuma tag XML válida detectada.")
        }
      }
      "json" -> {
        val trimmed = content.trim()
        if (!(trimmed.startsWith("{") && trimmed.endsWith("}")) && !(trimmed.startsWith("[") && trimmed.endsWith("]"))) {
          diagnostics.add("Possível erro JSON: o documento não inicia/termina com '{ }' ou '[ ]'.")
        }
        val keys = Regex(""""([A-Za-z0-9_.-]+)"\s*:""").findAll(content).map { it.groupValues[1] }.distinct().take(10).toList()
        if (keys.isNotEmpty()) {
          highlights.add("Chaves principais: ${keys.joinToString(", ")}")
        }
      }
      else -> {
        val words = content.split(Regex("\\s+")).count { it.isNotBlank() }
        highlights.add("Contagem de palavras analisadas: $words palavras em $totalLines linhas.")
      }
    }

    return buildString {
      appendLine("ANÁLISE DE CÓDIGO / TEXTO (.${ext.uppercase(Locale.US)})")
      appendLine("• Total de linhas: $totalLines${if (truncated) " (amostra analisada: primeiras 300 linhas)" else ""}")
      if (highlights.isNotEmpty()) {
        appendLine()
        appendLine("RESUMO TÉCNICO:")
        highlights.forEach { appendLine("• $it") }
      }
      if (diagnostics.isNotEmpty()) {
        appendLine()
        appendLine("DIAGNÓSTICO E PONTOS DE ATENÇÃO:")
        diagnostics.forEach { appendLine("• $it") }
      } else {
        appendLine()
        appendLine("DIAGNÓSTICO: Nenhum erro estrutural evidente detectado na amostra lida.")
      }
      appendLine()
      appendLine("PRÉVIA DO CONTEÚDO:")
      lines.take(14).forEachIndexed { idx, l ->
        appendLine("${idx + 1}: ${l.take(120)}")
      }
    }
  }

  private fun inspectFallbackTextOrBinary(
    context: Context,
    uri: Uri,
    meta: AttachedFileMeta,
  ): String {
    return runCatching {
        context.contentResolver.openInputStream(uri)?.use { input ->
          val sample = ByteArray(512)
          val read = input.read(sample)
          if (read <= 0) return@use "Arquivo vazio (0 bytes)."
          val printable = sample.take(read).count { b -> b in 32..126 || b == 10.toByte() || b == 13.toByte() || b == 9.toByte() }
          if (printable.toFloat() / read > 0.85f) {
            inspectTextCode(context, uri, meta, "txt")
          } else {
            "Arquivo binário identificado (${formatBytes(meta.sizeBytes)}). Para inspeção estrutural completa, envie arquivos .apk, .zip, .txt, .sh, .kt, .xml ou .json."
          }
        } ?: "Não foi possível abrir o arquivo selecionado."
      }
      .getOrDefault("Falha segura ao inspecionar o arquivo binário.")
  }

  fun formatBytes(bytes: Long): String {
    if (bytes <= 0L) return "0 B"
    return when {
      bytes < 1024L -> "$bytes B"
      bytes < 1024L * 1024L -> String.format(Locale.US, "%.1f KB", bytes / 1024.0)
      else -> String.format(Locale.US, "%.2f MB", bytes / (1024.0 * 1024.0))
    }
  }
}
