package com.example.engine

import java.util.Locale

object OfflineKnowledgeBase {

  fun answerHomeworkOrGeneral(prompt: String): String? {
    val lower = prompt.lowercase(Locale.getDefault())

    // 1. Real math calculation / equation solver
    MathSolver.trySolve(prompt)?.let { solved ->
      return solved
    }

    // 2. Mathematics conceptual topics
    if (containsAny(lower, "bhaskara", "pitagoras", "pitágoras", "regra de tres", "regra de 3", "matematica", "matemática", "equacao", "equação", "area do", "área do")) {
      return buildMathGuide(lower)
    }

    // 3. Portuguese grammar & essay
    if (containsAny(lower, "porques", "porquês", "porque", "crase", "redacao", "redação", "portugues", "português", "acentuacao", "acentuação", "ortografia")) {
      return buildPortugueseGuide(lower)
    }

    // 4. History
    if (containsAny(lower, "historia", "história", "independencia", "independência", "vargas", "revolucao industrial", "revolução industrial", "guerra mundial", "idade media", "idade média")) {
      return buildHistoryGuide(lower)
    }

    // 5. Science / Physics / Chemistry / Biology
    if (containsAny(lower, "newton", "fotossintese", "fotossíntese", "celula", "célula", "fisica", "física", "quimica", "química", "biologia", "ciencias", "ciências", "tabela periodica", "tabela periódica")) {
      return buildScienceGuide(lower)
    }

    // 6. Recipes
    if (containsAny(lower, "receita", "cozinhar", "bolo", "frango", "arroz", "panqueca", "omelete", "brigadeiro", "macarrao", "macarrão", "cafe", "café", "lanche", "ingrediente")) {
      return buildRecipeGuide(lower)
    }

    // 7. Video ideas & scripts
    if (containsAny(lower, "roteiro", "video", "vídeo", "tiktok", "reels", "shorts", "youtube", "gravar", "conteudo", "conteúdo")) {
      return buildVideoScriptGuide(prompt, lower)
    }

    return null
  }

  private fun buildMathGuide(lower: String): String {
    return when {
      lower.contains("pitag") ->
        """
        GUIA DE MATEMÁTICA — TEOREMA DE PITÁGORAS
        • Fórmula: a² = b² + c²
        • Onde 'a' é a hipotenusa (maior lado, oposto ao ângulo de 90°) e 'b', 'c' são os catetos.
        • Exemplo prático: se b = 3 e c = 4, então a² = 9 + 16 = 25 → a = √25 = 5.
        • Dica: você pode digitar uma conta direta aqui (ex: "15% de 320" ou "x^2 - 5x + 6 = 0") que eu calculo na hora!
        """.trimIndent()
      lower.contains("regra de") ->
        """
        GUIA DE MATEMÁTICA — REGRA DE 3 SIMPLES
        1. Organize as grandezas em duas colunas (A e B).
        2. Verifique se são diretamente proporcionais (aumenta uma, aumenta a outra → multiplique cruzado) ou inversamente proporcionais (aumenta uma, diminui a outra → multiplique em linha reta).
        3. Monte a equação: A₁ · x = A₂ · B₁ → x = (A₂ · B₁) / A₁.
        • Dica: envie qualquer conta como "(45 * 100) / 150" que eu resolvo imediatamente.
        """.trimIndent()
      else ->
        """
        GUIA RÁPIDO DE MATEMÁTICA OFFLINE
        • Bhaskara: Δ = b² - 4ac | x = (-b ± √Δ) / (2a)
        • Porcentagem: Valor × (Taxa ÷ 100)
        • Área do Triângulo: (base × altura) ÷ 2
        • Área do Círculo: π × r² (π ≈ 3,1416)
        • Juros Simples: J = C × i × t

        Dica interativa: envie diretamente no chat uma expressão como "25% de 480", "(12 + 8) * 3" ou "x^2 - 7x + 12 = 0" para eu calcular passo a passo!
        """.trimIndent()
    }
  }

  private fun buildPortugueseGuide(lower: String): String {
    return when {
      lower.contains("porqu") ->
        """
        USO DOS PORQUÊS (PORTUGUÊS)
        • "Por que" (separado, sem acento): início/meio de perguntas ou equivalente a "pelo qual". Ex: Por que você chegou cedo?
        • "Por quê" (separado, com acento): sempre no final da frase ou antes de pontuação. Ex: Não foi hoje, por quê?
        • "Porque" (junto, sem acento): usado em respostas e explicações (= pois). Ex: Estudei porque quero passar.
        • "Porquê" (junto, com acento): substantivo, sempre acompanhado de artigo/pronome (= o motivo). Ex: Não entendi o porquê disso.
        """.trimIndent()
      lower.contains("crase") ->
        """
        REGRAS ESSENCIAIS DE CRASE (à)
        1. Regra de ouro: troque a palavra feminina por uma masculina. Se virar "ao", tem crase! Ex: Vou à escola → Vou ao colégio (TEM crase).
        2. NUNCA use crase antes de: verbos (a partir, a fazer), palavras masculinas (a pé, a cavalo) e pronomes pessoais/indefinidos.
        3. SEMPRE use crase em: locuções femininas (às vezes, à noite, à direita, à medida que) e indicação de horas exatas (às 14h).
        """.trimIndent()
      else ->
        """
        ESTRUTURA DE REDAÇÃO NOTA 1000 (DISSERTATIVO-ARGUMENTATIVA)
        • Introdução (5–7 linhas): Contextualização + Repertório + Tese clara com 2 argumentos-chave.
        • Desenvolvimento 1 (7–8 linhas): Tópico frasal do Argumento 1 + Fundamentação + Exemplo/Análise crítica.
        • Desenvolvimento 2 (7–8 linhas): Conectivo (Além disso / Ademais) + Argumento 2 + Aprofundamento.
        • Conclusão (6–7 linhas): Retomada da tese + Proposta de Intervenção completa:
          [Quem (Agente)] + [O quê (Ação)] + [Como (Meio/Modo)] + [Para quê (Finalidade)] + [Detalhamento].
        """.trimIndent()
    }
  }

  private fun buildHistoryGuide(lower: String): String {
    return when {
      lower.contains("vargas") ->
        """
        HISTÓRIA DO BRASIL — ERA VARGAS (1930–1945)
        • Governo Provisório (1930–1934): Fim da República Velha (café com leite), criação do Ministério do Trabalho e Código Eleitoral (voto feminino em 1932).
        • Governo Constitucional (1934–1937): Constituição de 1934 e polarização entre AIB e ANL.
        • Estado Novo (1937–1945): Ditadura centralizada, criação da CLT (1943), DIP (censura/propaganda) e CSN (industrialização de base).
        """.trimIndent()
      lower.contains("industrial") ->
        """
        REVOLUÇÃO INDUSTRIAL — RESUMO ESTRUTURADO
        • 1ª Fase (séc. XVIII, Inglaterra): Máquina a vapor, carvão mineral, indústria têxtil e êxodo rural.
        • 2ª Fase (séc. XIX): Eletricidade, petróleo, motor a combustão, aço e linha de montagem (Fordismo).
        • 3ª Fase (séc. XX–XXI): Informática, robótica, telecomunicações e automação digital.
        • Impactos: Urbanização acelerada, surgimento do proletariado, sindicatos e expansão global do capitalismo.
        """.trimIndent()
      else ->
        """
        RESUMO DE HISTÓRIA — LINHA DO TEMPO ESSENCIAL
        • Idade Média (476–1453): Feudalismo, poder da Igreja Católica, Cruzadas e Renascimento Comercial.
        • Independência do Brasil (1822): Crise do sistema colonial, chegada da Família Real (1808), Dia do Fico e proclamação às margens do Ipiranga.
        • 1ª Guerra Mundial (1914–1918): Imperialismo europeu, Tríplice Entente vs Tríplice Aliança, Tratado de Versalhes.
        • 2ª Guerra Mundial (1939–1945): Ascensão do totalitarismo, Eixo vs Aliados, criação da ONU e início da Guerra Fria.
        """.trimIndent()
    }
  }

  private fun buildScienceGuide(lower: String): String {
    return when {
      lower.contains("newton") ->
        """
        FÍSICA — AS 3 LEIS DE NEWTON
        1. Lei da Inércia: Todo corpo permanece em repouso ou em Movimento Retilíneo Uniforme (MRU) se a força resultante for nula.
        2. Princípio Fundamental da Dinâmica: F = m · a (Força Resultante = massa × aceleração, em Newtons).
        3. Ação e Reação: Toda força exercida sobre um corpo gera uma reação de mesma intensidade, mesma direção e sentido oposto, em corpos diferentes.
        """.trimIndent()
      lower.contains("fotoss") ->
        """
        BIOLOGIA — FOTOSSÍNTESE PASSO A PASSO
        • Equação geral: 6 CO₂ + 6 H₂O + Luz → C₆H₁₂O₆ (Glicose) + 6 O₂
        • Onde ocorre: Nos cloroplastos (clorofila) das células vegetais e algas.
        • Fase Clara (Fotoquímica): Nos tilacoides; absorve luz, quebra a água (fotólise) e libera O₂ + ATP/NADPH.
        • Fase Escura (Ciclo de Calvin): No estroma; fixa o CO₂ utilizando ATP e NADPH para formar glicose.
        """.trimIndent()
      else ->
        """
        CIÊNCIAS DA NATUREZA — RESUMO INTEGRADO
        • Física (Cinemática): Velocidade média Vm = ΔS / Δt | Aceleração a = ΔV / Δt.
        • Química (Ligações):
          - Iônica: Transferência de elétrons (Metal + Ametal).
          - Covalente: Compartilhamento de elétrons (Ametal + Ametal).
          - Metálica: Mar de elétrons livres entre cátions metálicos.
        • Biologia (Citologia): Procariontes (sem carioteca, ex: bactérias) vs Eucariontes (núcleo delimitado por membrana + organelas).
        """.trimIndent()
    }
  }

  private fun buildRecipeGuide(lower: String): String {
    return when {
      lower.contains("bolo") ->
        """
        RECEITA PASSO A PASSO — BOLO DE CHOCOLATE FOFINHO (40 min)
        Ingredientes:
        • 3 ovos • 1 xícara de açúcar • 1/2 xícara de óleo
        • 1 xícara de leite morno • 1 xícara de chocolate em pó
        • 2 xícaras de farinha de trigo • 1 colher (sopa) de fermento

        Modo de Preparo:
        1. Preaqueça o forno a 180 °C e unte uma forma média.
        2. Bata no liquidificador os ovos, açúcar, óleo, leite morno e chocolate por 2 minutos.
        3. Transfira para uma tigela, misture a farinha aos poucos com um fouet e finalize incorporando o fermento delicadamente.
        4. Asse por 35 a 40 minutos (faça o teste do palito antes de retirar).
        """.trimIndent()
      lower.contains("frango") || lower.contains("fit") || lower.contains("omelete") ->
        """
        RECEITA PASSO A PASSO — FRANGO GRELHADO SUCULENTO FIT (15 min)
        Ingredientes:
        • 300g de filé de peito de frango em tiras médias
        • 1 colher (chá) de azeite • 1 dente de alho amassado
        • Suco de 1/2 limão • Páprica defumada, orégano e sal a gosto

        Modo de Preparo:
        1. Tempere o frango com limão, alho, páprica e sal; deixe descansar por 10 minutos.
        2. Aqueça bem uma frigideira antiaderente com o azeite em fogo médio-alto.
        3. Grelhe os filés sem mexer nos primeiros 3 minutos para selar e dourar; vire e cozinhe por mais 3 minutos até ficarem macios por dentro.
        """.trimIndent()
      lower.contains("panqueca") ->
        """
        RECEITA PASSO A PASSO — PANQUECA RÁPIDA (15 min)
        Ingredientes:
        • 1 ovo • 1 xícara de leite • 1 xícara de farinha de trigo
        • 1 colher (sopa) de óleo • 1 pitada de sal

        Modo de Preparo:
        1. Bata tudo no liquidificador até formar uma massa lisa e homogênea.
        2. Aqueça uma frigideira untada com fio de óleo em fogo médio.
        3. Despeje uma concha fina, gire a frigideira e doure 1 minuto de cada lado. Recheie com frango, carne moída ou banana com canela!
        """.trimIndent()
      else ->
        """
        RECEITA PASSO A PASSO — ARROZ SOLTINHO PERFEITO (20 min)
        Ingredientes:
        • 1 xícara de arroz branco • 2 xícaras de água quente
        • 1 colher (sopa) de óleo ou azeite • 2 dentes de alho picados • Sal a gosto

        Modo de Preparo:
        1. Refogue o alho no óleo em fogo baixo até começar a perfumar (sem queimar).
        2. Adicione o arroz e refogue por 2 minutos mexendo bem para selar os grãos.
        3. Despeje a água quente e o sal, misture uma única vez e deixe em fogo médio com a panela semitampada até a água nivelar com o arroz.
        4. Abaixe para fogo mínimo, tampe totalmente por ~8 minutos até secar e desligue.
        """.trimIndent()
    }
  }

  private fun buildVideoScriptGuide(rawPrompt: String, lower: String): String {
    val niche =
      when {
        containsAny(lower, "jogo", "game", "free fire", "sensi", "ff") -> "Games & Performance Mobile"
        containsAny(lower, "app", "tech", "celular", "android", "ia") -> "Tecnologia & Apps Android"
        containsAny(lower, "receita", "comida", "culinaria") -> "Gastronomia Rápida"
        else -> "Criador Digital / Shorts & Reels"
      }

    return """
    ROTEIRO PRONTO PARA GRAVAÇÃO ($niche)
    Tema base: "${rawPrompt.take(70)}"

    [00s - 03s] GANCHO VISUAL (Retenção máxima):
    • Fale com energia olhando para a câmera: "Você está configurando isso errado no seu celular — olha o que muda em 10 segundos!"
    • Texto grande na tela: "SEGREDO REVELADO ⚡"

    [03s - 22s] DESENVOLVIMENTO (Entrega de valor):
    • Passo 1: Mostre o problema real na tela (corte rápido a cada 2,5 segundos).
    • Passo 2: Apresente a solução prática com foco fechado ou gravação de tela em 60fps.
    • Passo 3: Mostre o antes e o depois com números reais.

    [22s - 30s] CHAMADA PARA AÇÃO (CTA):
    • "Salva esse vídeo para testar depois e comenta 'QUERO' se quiser a parte 2 com o passo a passo completo!"

    Dicas de Gravação:
    • Enquadramento vertical 9:16 (1080×1920), 60fps, áudio próximo ao microfone e legendas dinâmicas no terço inferior.
    """.trimIndent()
  }

  private fun containsAny(text: String, vararg keywords: String): Boolean =
    keywords.any { text.contains(it) }
}
