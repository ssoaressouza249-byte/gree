package com.example.engine

import android.content.Context
import android.net.Uri
import com.example.model.ChatMessage
import com.example.model.DeviceProfile
import com.example.model.MessageSender
import com.example.model.ResponseCategory
import java.util.Locale
import java.util.UUID
import kotlin.math.roundToInt

data class BrainReply(
  val text: String,
  val category: ResponseCategory,
  val generatedArt: com.example.model.GeneratedArtPayload? = null,
)

class LocalBrainEngine {

  fun processPrompt(
    context: Context,
    prompt: String,
    deviceProfile: DeviceProfile,
  ): BrainReply {
    val clean = prompt.trim()
    val lower = clean.lowercase(Locale.getDefault())

    // 1. Procedural Image Generation (Canvas + Bitmap)
    if (isImageGenerationIntent(lower)) {
      val artResult = ProceduralArtEngine.generateArt(clean)
      return artResult.fold(
        onSuccess = { payload ->
          BrainReply(
            text =
              buildString {
                appendLine("ARTE PROCEDURAL GERADA COM SUCESSO")
                appendLine("━━━━━━━━━━━━━━━━━━━━━━")
                appendLine("• Estilo: ${payload.styleLabel}")
                appendLine("• Tema extraído: ${payload.title}")
                appendLine("• Resolução nativa: ${payload.resolutionLabel} px (PNG alta definição)")
                append("Toque em \"Salvar na Galeria\" abaixo para exportar a imagem.")
              },
            category = ResponseCategory.PROCEDURAL_ART,
            generatedArt = payload,
          )
        },
        onFailure = { err ->
          BrainReply(
            text = "Não foi possível renderizar a arte procedural neste momento (${err.localizedMessage ?: "erro de memória"}). Tente um prompt mais curto.",
            category = ResponseCategory.PROCEDURAL_ART,
          )
        },
      )
    }

    // 2. Gamer Sensitivity / HUD / DPI / Stretched Screen / Brevent Specialist
    if (isGamerCalibrationIntent(lower)) {
      return BrainReply(
        text = buildGamerCalibrationResponse(deviceProfile, lower),
        category = ResponseCategory.GAMER_SENSITIVITY,
      )
    }

    // 3. App Creation Mentor (Technical Prompt + AI Studio + GitHub Actions)
    if (isAppMentorIntent(lower)) {
      return BrainReply(
        text = buildAppMentorResponse(clean),
        category = ResponseCategory.APP_MENTOR,
      )
    }

    // 4. Hardware Diagnostics Scanner Query
    if (isHardwareScanIntent(lower)) {
      return BrainReply(
        text = buildHardwareReport(deviceProfile),
        category = ResponseCategory.GAMER_SENSITIVITY,
      )
    }

    // 5. Offline Knowledge Base (Math, Homework, Recipes, Video Scripts)
    OfflineKnowledgeBase.answerHomeworkOrGeneral(clean)?.let { knowledgeReply ->
      return BrainReply(
        text = knowledgeReply,
        category = ResponseCategory.KNOWLEDGE,
      )
    }

    // 6. Intelligent Fallback / Assistant Capabilities Guide
    return BrainReply(
      text = buildSmartFallback(clean, deviceProfile),
      category = ResponseCategory.KNOWLEDGE,
    )
  }

  fun inspectAttachedFile(
    context: Context,
    uri: Uri,
    userPrompt: String,
  ): ChatMessage {
    val reportResult = FileInspectorEngine.inspectUri(context, uri, userPrompt)
    val replyText =
      reportResult.fold(
        onSuccess = { it.summaryText },
        onFailure = { err ->
          "Falha protegida ao analisar o arquivo selecionado: ${err.localizedMessage ?: "formato inacessível"}. Verifique se o arquivo ainda existe no armazenamento."
        },
      )

    return ChatMessage(
      id = UUID.randomUUID().toString(),
      sender = MessageSender.AI,
      text = replyText,
      category = ResponseCategory.FILE_INSPECTOR,
      attachedFile = reportResult.getOrNull()?.meta,
    )
  }

  private fun isImageGenerationIntent(lower: String): Boolean {
    val triggers =
      listOf(
        "gerar imagem",
        "gere imagem",
        "gere uma imagem",
        "criar imagem",
        "crie uma imagem",
        "criar logo",
        "crie uma logo",
        "fazer logo",
        "fazer banner",
        "criar banner",
        "gerar banner",
        "wallpaper",
        "papel de parede",
        "arte cyberpunk",
        "arte gamer",
        "gerar arte",
        "criar arte",
      )
    return triggers.any { lower.contains(it) }
  }

  private fun isGamerCalibrationIntent(lower: String): Boolean {
    val triggers =
      listOf(
        "sensi",
        "sensibilidade",
        "hud",
        "dpi",
        "mira",
        "tela esticada",
        "esticar tela",
        "free fire",
        "capa",
        "brevent",
        "awm",
        "ponto vermelho",
        "botão de atirar",
        "botao de atirar",
      )
    return triggers.any { lower.contains(it) }
  }

  private fun isAppMentorIntent(lower: String): Boolean {
    val triggers =
      listOf(
        "criar app",
        "criar um app",
        "fazer um app",
        "fazer aplicativo",
        "criar aplicativo",
        "gerar apk",
        "compilar apk",
        "ai studio",
        "github actions",
        "prompt de app",
        "desenvolver um app",
        "como fazer um aplicativo",
      )
    return triggers.any { lower.contains(it) }
  }

  private fun isHardwareScanIntent(lower: String): Boolean {
    val triggers =
      listOf(
        "meu celular",
        "meu aparelho",
        "hardware",
        "scanner",
        "especificações",
        "especificacoes",
        "ficha técnica",
        "ficha tecnica",
        "quanta ram",
        "quantos hz",
        "taxa de atualização",
        "taxa de atualizacao",
      )
    return triggers.any { lower.contains(it) }
  }

  private fun buildGamerCalibrationResponse(device: DeviceProfile, lower: String): String {
    val maxHz = device.maxRefreshRateHz.roundToInt().coerceIn(60, 240)
    val ramGb = device.totalRamGb
    val longSide = maxOf(device.screenWidthPx, device.screenHeightPx)
    val shortSide = minOf(device.screenWidthPx, device.screenHeightPx)

    // Calibração matemática exclusiva com base no hardware real do aparelho
    val hzAdjust =
      when {
        maxHz >= 120 -> -3
        maxHz >= 90 -> -1
        else -> 3
      }
    val dpiAdjust =
      when {
        device.densityDpi >= 480 -> -2
        device.densityDpi <= 320 -> 3
        else -> 0
      }

    val geral = (95 + hzAdjust + dpiAdjust).coerceIn(88, 100)
    val redDot = (92 + hzAdjust + dpiAdjust).coerceIn(85, 100)
    val mira2x = (90 + hzAdjust).coerceIn(84, 98)
    val mira4x = (87 + hzAdjust).coerceIn(80, 96)
    val awm = (54 + (if (maxHz >= 120) -4 else 4)).coerceIn(42, 68)
    val olhadinha = (78 + hzAdjust).coerceIn(65, 92)

    val fireButtonPct =
      when {
        shortSide >= 1200 -> 44
        device.densityDpi >= 440 -> 47
        else -> 51
      }

    val recommendedSw =
      when {
        device.smallestWidthDp >= 410 -> 580
        device.smallestWidthDp >= 380 -> 540
        else -> 490
      }

    val stretchedW = (shortSide * 0.85f).roundToInt()
    val stretchedH = (longSide * 0.90f).roundToInt()
    val targetWmDensity = (device.densityDpi * 0.80f).roundToInt().coerceIn(260, 440)

    val graphicsPreset =
      when {
        ramGb >= 7.5 && maxHz >= 90 -> "Ultra + Alto FPS ($maxHz Hz)"
        ramGb >= 5.5 -> "Padrão + Alto FPS ($maxHz Hz) para estabilidade térmica"
        else -> "Suave + Alto FPS para zero quedas de quadro"
      }

    val includeStretched = lower.contains("esticada") || lower.contains("brevent") || lower.contains("hud") || lower.contains("dpi")

    return buildString {
      appendLine("CALIBRAGEM EXCLUSIVA — ${device.manufacturer.uppercase(Locale.US)} ${device.model.uppercase(Locale.US)}")
      appendLine("━━━━━━━━━━━━━━━━━━━━━━")
      appendLine("TELEMETRIA REAL DETECTADA:")
      appendLine("• Tela: ${device.screenWidthPx}×${device.screenHeightPx} px (${device.aspectRatioLabel}) • ${device.densityDpi} DPI")
      appendLine("• Menor Largura (SW): ${device.smallestWidthDp} dp • Taxa: ${maxHz} Hz")
      appendLine("• Memória RAM: ${String.format(Locale.US, "%.1f", ramGb)} GB • Android ${device.androidVersion}")
      appendLine()
      appendLine("SENSIBILIDADE CALIBRADA PARA ESTE SENSOR:")
      appendLine("• Geral: $geral")
      appendLine("• Ponto Vermelho (Red Dot): $redDot")
      appendLine("• Mira 2x: $mira2x")
      appendLine("• Mira 4x: $mira4x")
      appendLine("• Mira AWM: $awm")
      appendLine("• Olhadinha: $olhadinha")
      appendLine("• Botão de Atirar: $fireButtonPct% (posicionado a 18% da borda inferior)")
      appendLine("• Preset Gráfico Ideal: $graphicsPreset")
      appendLine()
      appendLine("DPI & TELA ESTICADA RECOMENDADAS:")
      appendLine("• Menor Largura (Opções do Desenvolvedor): ${recommendedSw} dp (seguro para ${device.manufacturer})")
      if (includeStretched) {
        appendLine("• Proporção Tela Esticada (4:3 / 16:10): ${stretchedW}×${stretchedH}")
      }
      appendLine("• Dica HUD (3 Dedos): Disparo secundário ou Gel no canto superior esquerdo; Agachar acima do botão de atirar para movimento rápido.")
      appendLine()
      appendLine("COMANDOS BREVENT (SEM ROOT):")
      appendLine("wm density $targetWmDensity")
      appendLine("settings put system pointer_speed 7")
      if (device.sdkInt >= 30) {
        appendLine("cmd power set-fixed-performance-mode-enabled true")
      }
      appendLine("• Para restaurar padrão original: wm density reset && wm size reset")
    }
  }

  private fun buildAppMentorResponse(rawPrompt: String): String {
    val cleanIdea =
      rawPrompt
        .replace(Regex("(?i)(quero|preciso|como|criar|fazer|um|app|aplicativo|para|de)"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()
        .ifBlank { "aplicativo utilitário moderno em Jetpack Compose" }

    return """
    MENTOR DE ARQUITETURA ANDROID (AI STUDIO + GITHUB ACTIONS)
    ━━━━━━━━━━━━━━━━━━━━━━
    Nota técnica: Aplicativos Android completos devem ser compilados via Gradle na nuvem/CI e não diretamente dentro de um chat offline. Abaixo está o prompt técnico pronto para gerar o projeto perfeito e o roteiro de build:

    1. PROMPT TÉCNICO COMPLETO (Copie e cole no AI Studio):
    ──────────────────────────────────
    "Crie um app Android nativo em Kotlin com Jetpack Compose, Material 3, compileSdk 36, targetSdk 36, minSdk 26 e Gradle Kotlin DSL para: $cleanIdea.
    Requisitos técnicos:
    - Arquitetura MVVM com ViewModel + StateFlow e tratamento de erros com runCatching.
    - Interface escura ou adaptativa com Edge-to-Edge (enableEdgeToEdge) e WindowInsets corretos.
    - Navegação segura e persistência local leve (SharedPreferences ou Room conforme necessário).
    - Ícone adaptativo customizado, strings em res/values/strings.xml e zero permissões desnecessárias para conformidade com a Google Play Store."
    ──────────────────────────────────

    2. PASSO A PASSO PARA COMPILAR O APK VIA GITHUB ACTIONS:
    • Passo 1: Cole o prompt acima no AI Studio e aguarde a geração completa dos arquivos Kotlin/Gradle.
    • Passo 2: Exporte o projeto (Download ZIP ou Push direto para um repositório no seu GitHub).
    • Passo 3: No repositório GitHub, crie o arquivo `.github/workflows/build.yml` com:
      - `actions/checkout@v4`
      - `actions/setup-java@v4` (distribution: 'temurin', java-version: '17')
      - Comando: `./gradlew assembleDebug` (ou `gradle assembleDebug`)
      - `actions/upload-artifact@v4` apontando para `app/build/outputs/apk/debug/*.apk`
    • Passo 4: Acesse a aba "Actions" no GitHub, aguarde o check verde e baixe o APK compilado com segurança!
    """.trimIndent()
  }

  private fun buildHardwareReport(device: DeviceProfile): String {
    return """
    SCANNER DE HARDWARE EM TEMPO REAL
    ━━━━━━━━━━━━━━━━━━━━━━
    • Fabricante: ${device.manufacturer}
    • Modelo: ${device.model} (${device.deviceCode})
    • Processador / SoC: ${device.chipInfo}
    • Sistema: Android ${device.androidVersion} (API ${device.sdkInt})
    • Memória RAM Total: ${String.format(Locale.US, "%.2f", device.totalRamGb)} GB
    • Memória RAM Livre Agora: ${String.format(Locale.US, "%.2f", device.availableRamGb)} GB
    • Resolução Real da Tela: ${device.screenWidthPx} × ${device.screenHeightPx} px (${device.aspectRatioLabel})
    • Densidade Nativa: ${device.densityDpi} DPI (SW: ${device.smallestWidthDp} dp)
    • Taxa de Atualização: ${device.currentRefreshRateHz.roundToInt()} Hz (Máxima suportada: ${device.maxRefreshRateHz.roundToInt()} Hz)
    • Categoria de Desempenho: ${device.performanceTier}

    Quer que eu gere sua Sensi, DPI e comandos Brevent calibrados exatamente para este ${device.model}? Basta pedir "Gerar sensi e DPI"!
    """.trimIndent()
  }

  private fun buildSmartFallback(prompt: String, device: DeviceProfile): String {
    val lower = prompt.lowercase(Locale.getDefault())
    val isGreeting =
      lower in setOf("oi", "olá", "ola", "eae", "bom dia", "boa tarde", "boa noite", "help", "ajuda")

    return if (isGreeting) {
      """
      GREENCORE AI — NÚCLEO OFFLINE ATIVO
      ━━━━━━━━━━━━━━━━━━━━━━
      Olá! Estou operando 100% localmente no seu ${device.manufacturer} ${device.model} (sem consumo de internet ou APIs externas).

      Escolha ou digite o que deseja fazer agora:
      • Calibragem Gamer: "Sensi, DPI e comando Brevent para meu celular"
      • Gerador de Arte Nativo: "Gerar wallpaper gamer cyberpunk" ou "Criar logo neon"
      • Inspetor de Arquivos: Toque no clipe (📎) para analisar .apk, .zip, .sh, .kt ou .txt
      • Mentor de Apps: "Quero criar um app de controle financeiro"
      • Estudos, Receitas & Vídeos: "x^2 - 5x + 6 = 0", "Uso dos porquês", "Receita de bolo" ou "Roteiro para Reels"
      """.trimIndent()
    } else {
      """
      ANÁLISE LOCAL GREENCORE AI
      ━━━━━━━━━━━━━━━━━━━━━━
      Recebi sua solicitação: "$prompt"

      Como opero 100% offline com motor determinístico em Kotlin no seu ${device.model}, posso entregar respostas completas e precisas nas seguintes especialidades:
      1. Calibragem de Hardware (Sensi, Mira, DPI, Tela Esticada e Brevent)
      2. Geração de Imagens/Logos/Wallpapers 1080p em Canvas Nativo
      3. Inspeção Técnica de Arquivos (.apk, .zip, .sh, .kt, .xml, .txt) via botão de anexo (📎)
      4. Cálculos Matemáticos (Expressões, Porcentagem, Bhaskara) e Guias Escolares
      5. Mentor de Criação de Apps (Prompt Técnico + GitHub Actions)
      6. Receitas Culinárias Passo a Passo e Roteiros de Vídeo

      Reformule com uma palavra-chave (ex: "Sensi", "Gerar logo", "Criar app", "Receita", "Bhaskara") ou anexe um arquivo para análise imediata!
      """.trimIndent()
    }
  }
}
