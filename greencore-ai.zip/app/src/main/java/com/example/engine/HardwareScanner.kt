package com.example.engine

import android.app.ActivityManager
import android.content.Context
import android.hardware.display.DisplayManager
import android.os.Build
import android.util.DisplayMetrics
import android.view.Display
import android.view.WindowManager
import com.example.model.DeviceProfile
import java.util.Locale

object HardwareScanner {

  fun scanDevice(context: Context): DeviceProfile {
    val manufacturer =
      runCatching {
          Build.MANUFACTURER.orEmpty()
            .trim()
            .replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() }
            .ifBlank { "Android" }
        }
        .getOrDefault("Android")

    val model = runCatching { Build.MODEL.orEmpty().trim().ifBlank { "Dispositivo" } }.getOrDefault("Dispositivo")
    val deviceCode = runCatching { Build.DEVICE.orEmpty().trim().ifBlank { "generic" } }.getOrDefault("generic")

    val chipInfo =
      runCatching {
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val soc = Build.SOC_MODEL.orEmpty().trim()
            if (soc.isNotBlank() && soc != Build.UNKNOWN) soc else Build.HARDWARE.orEmpty()
          } else {
            Build.HARDWARE.orEmpty()
          }.ifBlank { "ARM64" }
        }
        .getOrDefault("ARM64")

    val androidVersion = runCatching { Build.VERSION.RELEASE.orEmpty().ifBlank { "14" } }.getOrDefault("14")
    val sdkInt = Build.VERSION.SDK_INT

    var totalRam = 4L * 1024L * 1024L * 1024L
    var availRam = 2L * 1024L * 1024L * 1024L
    runCatching {
      val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
      if (activityManager != null) {
        val memInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memInfo)
        if (memInfo.totalMem > 0L) totalRam = memInfo.totalMem
        if (memInfo.availMem > 0L) availRam = memInfo.availMem
      }
    }

    val resourcesMetrics = runCatching { context.resources.displayMetrics }.getOrNull()
    var widthPx = resourcesMetrics?.widthPixels ?: 1080
    var heightPx = resourcesMetrics?.heightPixels ?: 2400
    val densityDpi = resourcesMetrics?.densityDpi ?: 420
    val smallestWidthDp =
      runCatching { context.resources.configuration.smallestScreenWidthDp }
        .getOrDefault(360)
        .coerceAtLeast(240)

    runCatching {
      val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && windowManager != null) {
        val bounds = windowManager.maximumWindowMetrics.bounds
        if (bounds.width() > 0 && bounds.height() > 0) {
          widthPx = bounds.width()
          heightPx = bounds.height()
        }
      } else {
        val displayManager = context.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
        val display = displayManager?.getDisplay(Display.DEFAULT_DISPLAY)
        if (display != null) {
          val realMetrics = DisplayMetrics()
          @Suppress("DEPRECATION")
          display.getRealMetrics(realMetrics)
          if (realMetrics.widthPixels > 0 && realMetrics.heightPixels > 0) {
            widthPx = realMetrics.widthPixels
            heightPx = realMetrics.heightPixels
          }
        }
      }
    }

    var currentHz = 60f
    var maxHz = 60f
    runCatching {
      val displayManager = context.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
      val display = displayManager?.getDisplay(Display.DEFAULT_DISPLAY)
      if (display != null) {
        currentHz = display.refreshRate.takeIf { it > 1f } ?: 60f
        val supportedMax =
          display.supportedModes?.maxOfOrNull { it.refreshRate }?.takeIf { it > 1f } ?: currentHz
        maxHz = maxOf(currentHz, supportedMax)
      }
    }

    return DeviceProfile(
      manufacturer = manufacturer,
      model = model,
      deviceCode = deviceCode,
      chipInfo = chipInfo,
      androidVersion = androidVersion,
      sdkInt = sdkInt,
      totalRamBytes = totalRam,
      availableRamBytes = availRam,
      screenWidthPx = widthPx,
      screenHeightPx = heightPx,
      densityDpi = densityDpi,
      smallestWidthDp = smallestWidthDp,
      currentRefreshRateHz = currentHz,
      maxRefreshRateHz = maxHz,
    )
  }
}
