package com.example.engine

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.example.model.GeneratedArtPayload
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

object ProceduralArtEngine {

  private data class ArtPalette(
    val bgTop: Int,
    val bgBottom: Int,
    val primaryNeon: Int,
    val secondaryNeon: Int,
    val accentGlow: Int,
    val label: String,
  )

  fun generateArt(prompt: String): Result<GeneratedArtPayload> {
    return runCatching {
      val lower = prompt.lowercase(Locale.getDefault())
      val isPortraitWallpaper =
        lower.contains("wallpaper") ||
          lower.contains("papel de parede") ||
          lower.contains("celular") ||
          lower.contains("vertical") ||
          lower.contains("story")

      val width = 1080
      val height = if (isPortraitWallpaper) 1920 else 1080
      val resolutionLabel = "${width}×${height}"

      val styleLabel =
        when {
          lower.contains("logo") -> "Logo Vetorial Neon"
          lower.contains("banner") -> "Banner Cyberpunk"
          isPortraitWallpaper -> "Wallpaper Gamer HD"
          else -> "Arte Procedural Neon"
        }

      val palette = selectPalette(lower)
      val displayTitle = extractThemeTitle(prompt)
      val seed = prompt.hashCode().toLong() xor (System.currentTimeMillis() / 10_000L)
      val random = Random(seed)

      val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
      val canvas = Canvas(bitmap)

      drawBackground(canvas, width, height, palette)
      drawPerspectiveGrid(canvas, width, height, palette)
      drawCircuitTraces(canvas, width, height, palette, random)
      drawCyberCoreGeometry(canvas, width, height, palette, random)
      drawParticleField(canvas, width, height, palette, random)
      drawScanlinesAndFrame(canvas, width, height, palette)
      drawThemeTypography(canvas, width, height, palette, displayTitle, styleLabel)

      GeneratedArtPayload(
        bitmap = bitmap,
        title = displayTitle,
        resolutionLabel = resolutionLabel,
        styleLabel = styleLabel,
      )
    }
  }

  fun saveBitmapToGallery(context: Context, bitmap: Bitmap, title: String): Result<String> {
    return runCatching {
      val safeName =
        title
          .lowercase(Locale.US)
          .replace(Regex("[^a-z0-9]+"), "_")
          .trim('_')
          .ifBlank { "art" }
          .take(24)
      val fileName = "GreenCore_${safeName}_${System.currentTimeMillis()}.png"

      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        val values =
          ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/GreenCoreAI")
            put(MediaStore.Images.Media.IS_PENDING, 1)
          }
        val resolver = context.contentResolver
        val uri =
          resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: error("Falha ao criar registro no MediaStore.")

        resolver.openOutputStream(uri)?.use { out ->
          if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) {
            error("Falha ao comprimir imagem PNG.")
          }
        } ?: error("Não foi possível abrir fluxo de escrita.")

        values.clear()
        values.put(MediaStore.Images.Media.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
        "Galeria (Pictures/GreenCoreAI/$fileName)"
      } else {
        // Fallback seguro para API 26-28 sem exigir permissões amplas de armazenamento
        val mediaResult =
          runCatching {
            val values =
              ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
              }
            val resolver = context.contentResolver
            val uri =
              resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: error("MediaStore indisponível")
            resolver.openOutputStream(uri)?.use { out ->
              bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            }
            "Galeria ($fileName)"
          }

        if (mediaResult.isSuccess) {
          mediaResult.getOrThrow()
        } else {
          val dir =
            context.getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: context.filesDir
          if (!dir.exists()) dir.mkdirs()
          val outFile = File(dir, fileName)
          FileOutputStream(outFile).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
          }
          "Armazenamento do App (${outFile.name})"
        }
      }
    }
  }

  private fun selectPalette(lower: String): ArtPalette {
    return when {
      lower.contains("vermelho") || lower.contains("fogo") || lower.contains("red") ->
        ArtPalette(
          bgTop = Color.parseColor("#000000"),
          bgBottom = Color.parseColor("#180406"),
          primaryNeon = Color.parseColor("#FF2A54"),
          secondaryNeon = Color.parseColor("#00FF66"),
          accentGlow = Color.parseColor("#FF6B00"),
          label = "CRIMSON CYBER",
        )
      lower.contains("azul") || lower.contains("cyan") || lower.contains("gelo") ->
        ArtPalette(
          bgTop = Color.parseColor("#000000"),
          bgBottom = Color.parseColor("#02141A"),
          primaryNeon = Color.parseColor("#00F0FF"),
          secondaryNeon = Color.parseColor("#00FF66"),
          accentGlow = Color.parseColor("#3B82F6"),
          label = "CYBER ICE",
        )
      lower.contains("roxo") || lower.contains("purple") || lower.contains("violet") ->
        ArtPalette(
          bgTop = Color.parseColor("#000000"),
          bgBottom = Color.parseColor("#12031C"),
          primaryNeon = Color.parseColor("#B829FF"),
          secondaryNeon = Color.parseColor("#00FF66"),
          accentGlow = Color.parseColor("#00E5FF"),
          label = "NEON VIOLET",
        )
      else ->
        ArtPalette(
          bgTop = Color.parseColor("#000000"),
          bgBottom = Color.parseColor("#03170B"),
          primaryNeon = Color.parseColor("#00FF66"),
          secondaryNeon = Color.parseColor("#00CC52"),
          accentGlow = Color.parseColor("#80FFB3"),
          label = "GREENCORE MATRIX",
        )
    }
  }

  private fun drawBackground(canvas: Canvas, w: Int, h: Int, palette: ArtPalette) {
    val bgPaint =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader =
          LinearGradient(
            0f,
            0f,
            0f,
            h.toFloat(),
            palette.bgTop,
            palette.bgBottom,
            Shader.TileMode.CLAMP,
          )
      }
    canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), bgPaint)

    val cx = w / 2f
    val cy = h * 0.44f
    val glowRadius = w * 0.65f
    val glowPaint =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader =
          RadialGradient(
            cx,
            cy,
            glowRadius,
            intArrayOf(
              Color.argb(90, Color.red(palette.primaryNeon), Color.green(palette.primaryNeon), Color.blue(palette.primaryNeon)),
              Color.argb(25, Color.red(palette.secondaryNeon), Color.green(palette.secondaryNeon), Color.blue(palette.secondaryNeon)),
              Color.TRANSPARENT,
            ),
            floatArrayOf(0f, 0.48f, 1f),
            Shader.TileMode.CLAMP,
          )
      }
    canvas.drawCircle(cx, cy, glowRadius, glowPaint)
  }

  private fun drawPerspectiveGrid(canvas: Canvas, w: Int, h: Int, palette: ArtPalette) {
    val horizonY = h * 0.60f
    val gridPaint =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = palette.primaryNeon
        alpha = 52
        strokeWidth = 2.2f
        style = Paint.Style.STROKE
      }

    // Horizontal perspective lines
    val rows = 14
    for (i in 0..rows) {
      val t = i.toFloat() / rows
      val y = horizonY + (t * t) * (h - horizonY)
      gridPaint.alpha = (25 + (t * 90)).toInt().coerceIn(20, 120)
      canvas.drawLine(0f, y, w.toFloat(), y, gridPaint)
    }

    // Vanishing radial lines
    val vanishX = w / 2f
    val cols = 14
    for (i in -cols..cols) {
      val bottomX = vanishX + i * (w * 0.14f)
      gridPaint.alpha = 58
      canvas.drawLine(vanishX, horizonY, bottomX, h.toFloat(), gridPaint)
    }

    // Upper subtle tech grid
    val topGridPaint =
      Paint().apply {
        color = palette.secondaryNeon
        alpha = 18
        strokeWidth = 1.5f
      }
    val step = 90f
    var x = 0f
    while (x <= w) {
      canvas.drawLine(x, 0f, x, horizonY, topGridPaint)
      x += step
    }
    var y = 0f
    while (y <= horizonY) {
      canvas.drawLine(0f, y, w.toFloat(), y, topGridPaint)
      y += step
    }
  }

  private fun drawCircuitTraces(canvas: Canvas, w: Int, h: Int, palette: ArtPalette, random: Random) {
    val tracePaint =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = palette.primaryNeon
        alpha = 85
        strokeWidth = 3f
        style = Paint.Style.STROKE
      }
    val nodePaint =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = palette.accentGlow
        alpha = 180
        style = Paint.Style.FILL
      }

    repeat(14) { idx ->
      val startX = if (idx % 2 == 0) 0f else w.toFloat()
      val dir = if (idx % 2 == 0) 1f else -1f
      val startY = random.nextFloat() * h * 0.72f + h * 0.08f
      val len1 = random.nextFloat() * 180f + 90f
      val dy = (random.nextFloat() - 0.5f) * 140f
      val len2 = random.nextFloat() * 150f + 70f

      val path =
        Path().apply {
          moveTo(startX, startY)
          lineTo(startX + dir * len1, startY)
          lineTo(startX + dir * (len1 + 50f), startY + dy)
          lineTo(startX + dir * (len1 + 50f + len2), startY + dy)
        }
      canvas.drawPath(path, tracePaint)
      canvas.drawCircle(startX + dir * (len1 + 50f + len2), startY + dy, 7f, nodePaint)
    }
  }

  private fun drawCyberCoreGeometry(canvas: Canvas, w: Int, h: Int, palette: ArtPalette, random: Random) {
    val cx = w / 2f
    val cy = h * 0.42f
    val baseRadius = w * 0.27f

    val glowStroke =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = palette.primaryNeon
        style = Paint.Style.STROKE
        strokeWidth = 8f
        maskFilter = BlurMaskFilter(26f, BlurMaskFilter.Blur.NORMAL)
      }

    val crispStroke =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = palette.primaryNeon
        style = Paint.Style.STROKE
        strokeWidth = 5f
      }

    val innerFill =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(170, 5, 14, 9)
        style = Paint.Style.FILL
      }

    val sides = if (random.nextBoolean()) 6 else 8
    val rotOffset = random.nextFloat() * 0.35f

    // Outer hexagon/octagon
    val outerPath = buildPolygonPath(cx, cy, baseRadius * 1.18f, sides, rotOffset)
    canvas.drawPath(outerPath, glowStroke)
    canvas.drawPath(outerPath, crispStroke)

    // Mid filled polygon
    val midPath = buildPolygonPath(cx, cy, baseRadius * 0.92f, sides, -rotOffset)
    canvas.drawPath(midPath, innerFill)
    val secondaryStroke =
      Paint(crispStroke).apply {
        color = palette.accentGlow
        strokeWidth = 3f
        alpha = 210
      }
    canvas.drawPath(midPath, secondaryStroke)

    // Concentric HUD arcs
    val hudRect = RectF(cx - baseRadius * 1.38f, cy - baseRadius * 1.38f, cx + baseRadius * 1.38f, cy + baseRadius * 1.38f)
    val arcPaint =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = palette.secondaryNeon
        style = Paint.Style.STROKE
        strokeWidth = 4f
        alpha = 180
      }
    for (seg in 0 until 6) {
      val startAngle = seg * 60f + random.nextFloat() * 14f
      canvas.drawArc(hudRect, startAngle, 34f, false, arcPaint)
    }

    // Inner core triangle / diamond lattice
    val corePath = buildPolygonPath(cx, cy, baseRadius * 0.48f, 3, (PI / 2).toFloat())
    val corePathInv = buildPolygonPath(cx, cy, baseRadius * 0.48f, 3, (-PI / 2).toFloat())
    canvas.drawPath(corePath, glowStroke)
    canvas.drawPath(corePath, crispStroke)
    canvas.drawPath(corePathInv, secondaryStroke)

    // Central pulsing dot
    val centerDot =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = palette.accentGlow
        style = Paint.Style.FILL
      }
    canvas.drawCircle(cx, cy, 18f, centerDot)
  }

  private fun buildPolygonPath(cx: Float, cy: Float, radius: Float, sides: Int, angleOffset: Float): Path {
    val path = Path()
    for (i in 0 until sides) {
      val angle = angleOffset + (2.0 * PI * i / sides).toFloat()
      val x = cx + radius * cos(angle)
      val y = cy + radius * sin(angle)
      if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    path.close()
    return path
  }

  private fun drawParticleField(canvas: Canvas, w: Int, h: Int, palette: ArtPalette, random: Random) {
    val pPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    repeat(65) {
      val px = random.nextFloat() * w
      val py = random.nextFloat() * h
      val radius = random.nextFloat() * 4.5f + 1.5f
      pPaint.color = if (it % 3 == 0) palette.accentGlow else palette.primaryNeon
      pPaint.alpha = random.nextInt(70, 210)
      canvas.drawCircle(px, py, radius, pPaint)
    }
  }

  private fun drawScanlinesAndFrame(canvas: Canvas, w: Int, h: Int, palette: ArtPalette) {
    val scanPaint =
      Paint().apply {
        color = Color.BLACK
        alpha = 42
        strokeWidth = 2f
      }
    var y = 0f
    while (y < h) {
      canvas.drawLine(0f, y, w.toFloat(), y, scanPaint)
      y += 8f
    }

    val borderPaint =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = palette.primaryNeon
        style = Paint.Style.STROKE
        strokeWidth = 6f
        alpha = 200
      }
    val margin = 28f
    canvas.drawRect(margin, margin, w - margin, h - margin, borderPaint)

    // Corner HUD brackets
    val cornerPaint =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = palette.accentGlow
        style = Paint.Style.STROKE
        strokeWidth = 10f
      }
    val b = 56f
    // Top-left
    canvas.drawLine(margin, margin, margin + b, margin, cornerPaint)
    canvas.drawLine(margin, margin, margin, margin + b, cornerPaint)
    // Top-right
    canvas.drawLine(w - margin - b, margin, w - margin, margin, cornerPaint)
    canvas.drawLine(w - margin, margin, w - margin, margin + b, cornerPaint)
    // Bottom-left
    canvas.drawLine(margin, h - margin, margin + b, h - margin, cornerPaint)
    canvas.drawLine(margin, h - margin - b, margin, h - margin, cornerPaint)
    // Bottom-right
    canvas.drawLine(w - margin - b, h - margin, w - margin, h - margin, cornerPaint)
    canvas.drawLine(w - margin, h - margin - b, w - margin, h - margin, cornerPaint)
  }

  private fun drawThemeTypography(
    canvas: Canvas,
    w: Int,
    h: Int,
    palette: ArtPalette,
    title: String,
    styleLabel: String,
  ) {
    val badgePaint =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = palette.primaryNeon
        typeface = Typeface.MONOSPACE
        textSize = 28f
        textAlign = Paint.Align.CENTER
        letterSpacing = 0.18f
      }
    canvas.drawText("[ ${palette.label} // ${styleLabel.uppercase(Locale.US)} ]", w / 2f, 92f, badgePaint)

    val titleY = if (h > w) h * 0.78f else h * 0.83f
    val boxPaint =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(205, 0, 0, 0)
        style = Paint.Style.FILL
      }
    val boxStroke =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = palette.primaryNeon
        style = Paint.Style.STROKE
        strokeWidth = 4f
      }
    val boxRect = RectF(72f, titleY - 76f, w - 72f, titleY + 54f)
    canvas.drawRoundRect(boxRect, 18f, 18f, boxPaint)
    canvas.drawRoundRect(boxRect, 18f, 18f, boxStroke)

    val fittedText = title.uppercase(Locale.US).take(22)
    val glowTextPaint =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = palette.primaryNeon
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        textSize = if (fittedText.length > 14) 44f else 56f
        textAlign = Paint.Align.CENTER
        maskFilter = BlurMaskFilter(14f, BlurMaskFilter.Blur.NORMAL)
      }
    val sharpTextPaint =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        textSize = glowTextPaint.textSize
        textAlign = Paint.Align.CENTER
      }

    canvas.drawText(fittedText, w / 2f, titleY + 6f, glowTextPaint)
    canvas.drawText(fittedText, w / 2f, titleY + 6f, sharpTextPaint)

    val footerPaint =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = palette.accentGlow
        typeface = Typeface.MONOSPACE
        textSize = 24f
        textAlign = Paint.Align.CENTER
        alpha = 200
      }
    canvas.drawText("GREENCORE AI • PROCEDURAL ENGINE ${w}x${h}", w / 2f, h - 56f, footerPaint)
  }

  private fun extractThemeTitle(prompt: String): String {
    val removeWords =
      setOf(
        "gerar",
        "gere",
        "crie",
        "criar",
        "fazer",
        "faça",
        "imagem",
        "logo",
        "banner",
        "wallpaper",
        "gamer",
        "papel",
        "de",
        "parede",
        "uma",
        "um",
        "para",
        "com",
        "tema",
        "estilo",
        "cyberpunk",
        "neon",
        "por",
        "favor",
      )
    val tokens =
      prompt
        .replace(Regex("[^\\p{L}\\p{N}\\s]"), " ")
        .split(Regex("\\s+"))
        .filter { it.isNotBlank() && it.lowercase(Locale.getDefault()) !in removeWords }

    return if (tokens.isNotEmpty()) {
      tokens.take(3).joinToString(" ")
    } else {
      "GREENCORE NEON"
    }
  }
}
